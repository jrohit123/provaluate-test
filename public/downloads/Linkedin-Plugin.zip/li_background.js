// ProValuate LinkedIn Extension - Background Service Worker
// Handles config storage, cookie sync (credentials from dashboard login), and message passing

const DEFAULT_API_BASE = 'https://flask-6421997997235322.kloudbeansite.com';
const DEFAULT_WEBSITE_URL = 'https://provaluate.aitamate.com';

// Cookie names: read both li_* and provaluate_* (dashboard sets provaluate_* on login — same as ProValuate Gmail extension)
const LI_COOKIE_NAMES = new Set([
  'li_user_id',
  'li_company_id',
  'li_api_base',
  'li_website_url',
  'provaluate_user_id',
  'provaluate_company_id',
  'provaluate_api_base',
  'provaluate_website_url'
]);

const decodeValue = (value) => {
  if (value == null) return value;
  try {
    return decodeURIComponent(value);
  } catch (e) {
    return value;
  }
};

const getWebsiteUrl = () =>
  new Promise((resolve) => {
    chrome.storage.sync.get(['li_websiteUrl'], (r) => {
      resolve(decodeValue(r.li_websiteUrl) || DEFAULT_WEBSITE_URL);
    });
  });

const getApiBaseUrl = () =>
  new Promise((resolve) => {
    chrome.storage.sync.get(['li_apiBase'], (r) => {
      resolve(decodeValue(r.li_apiBase) || DEFAULT_API_BASE);
    });
  });

const getCookiesAsync = (filter) =>
  new Promise((resolve) => {
    chrome.cookies.getAll(filter, (cookies) => {
      resolve(cookies || []);
    });
  });

function processCookies(cookies) {
  let userId = null;
  let companyId = null;
  let apiBase = null;
  let websiteUrl = null;
  cookies.forEach((c) => {
    const val = decodeValue(c.value);
    if (c.name === 'li_user_id' || c.name === 'provaluate_user_id') userId = val;
    else if (c.name === 'li_company_id' || c.name === 'provaluate_company_id') companyId = val;
    else if (c.name === 'li_api_base' || c.name === 'provaluate_api_base') apiBase = val;
    else if (c.name === 'li_website_url' || c.name === 'provaluate_website_url') websiteUrl = val;
  });
  return new Promise((resolve) => {
    chrome.storage.sync.get(['li_apiBase', 'li_websiteUrl', 'li_companyId', 'li_userId'], (result) => {
      const data = {};
      data.li_apiBase = decodeValue(apiBase || result.li_apiBase) || DEFAULT_API_BASE;
      data.li_websiteUrl = decodeValue(websiteUrl || result.li_websiteUrl) || DEFAULT_WEBSITE_URL;
      if (userId != null) data.li_userId = userId;
      else if (result.li_userId != null) data.li_userId = decodeValue(result.li_userId);
      else data.li_userId = '';
      if (companyId != null) data.li_companyId = companyId;
      else if (result.li_companyId != null) data.li_companyId = decodeValue(result.li_companyId);
      else data.li_companyId = '';
      chrome.storage.sync.set(data, () => resolve());
    });
  });
}

async function syncCookiesToStorage(trigger = '') {
  try {
    const websiteUrl = await getWebsiteUrl();
    const cookies = await getCookiesAsync({ url: websiteUrl });
    const relevant = cookies.filter((c) => LI_COOKIE_NAMES.has(c.name));
    if (relevant.length > 0) {
      await processCookies(relevant);
      return true;
    }
    const all = await getCookiesAsync({});
    const matched = all.filter((c) => LI_COOKIE_NAMES.has(c.name));
    if (matched.length > 0) {
      await processCookies(matched);
      return true;
    }
  } catch (e) {
    console.warn('[ProValuate LinkedIn] Cookie sync error:', e.message);
  }
  return false;
}

let pendingAssessment = null;

chrome.downloads.onCreated.addListener(async (downloadItem) => {
  if (!pendingAssessment) return;

  const filename = (downloadItem.filename || '').toLowerCase();
  const mime     = (downloadItem.mime || '').toLowerCase();
  const isPdf    = filename.endsWith('.pdf') || mime.includes('pdf');
  if (!isPdf) return;

  const assessment  = pendingAssessment;
  pendingAssessment = null;
  const downloadId  = downloadItem.id;

  notifyTab(assessment.tabId, { action: 'li_statusUpdate', message: 'PDF detected! Waiting for download...' });

  waitForDownloadComplete(downloadId, async (completedItem) => {
    if (!completedItem) {
      notifyTab(assessment.tabId, { action: 'li_assessmentError', error: 'PDF download did not complete' });
      return;
    }

    chrome.downloads.removeFile(downloadId, () => {
      console.log('[ProValuate] Local PDF file deleted immediately');
    });

    try {
      const fileBlob = await fetch(completedItem.finalUrl || completedItem.url, {
        credentials: 'include'
      }).then(r => r.blob());

      const safeName = assessment.candidateName.replace(/[^a-zA-Z0-9 ]/g, '_');
      const formData = new FormData();
      formData.append('file',           fileBlob, `${safeName}_LinkedIn.pdf`);
      formData.append('jd_id',          assessment.jdId       || '');
      formData.append('criteria_id',    assessment.criteriaId || '');
      formData.append('user_id',        assessment.userId     || '');
      formData.append('company_id',     assessment.companyId  || '');
      formData.append('candidate_name', assessment.candidateName || '');

      notifyTab(assessment.tabId, { action: 'li_statusUpdate', message: 'Uploading PDF to ProValuate...' });
      const uploadData = await fetch(`${assessment.apiBase}/cv/upload`, { method: 'POST', body: formData }).then(r => r.json());

      if (!uploadData.file_url) {
        notifyTab(assessment.tabId, { action: 'li_assessmentError', error: uploadData.error || 'Upload failed' });
        return;
      }

      notifyTab(assessment.tabId, { action: 'li_statusUpdate', message: 'Analyzing against job description...' });
      await fetch(`${assessment.apiBase}/cv/analyze_resumes`, {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({
          resume_urls: [uploadData.file_url],
          jd_id:       assessment.jdId,
          criteria_id: assessment.criteriaId,
          user_id:     assessment.userId,
          company_id:  assessment.companyId
        })
      });

      notifyTab(assessment.tabId, {
        action: 'li_assessmentComplete',
        candidateName: assessment.candidateName,
        websiteUrl: assessment.websiteUrl
      });

    } catch (err) {
      notifyTab(assessment.tabId, { action: 'li_assessmentError', error: err.message });
    }
  });
});

function waitForDownloadComplete(downloadId, callback) {
  const interval = 600;
  let elapsed = 0;
  const timer = setInterval(() => {
    elapsed += interval;
    if (elapsed > 60000) { clearInterval(timer); callback(null); return; }
    chrome.downloads.search({ id: downloadId }, (results) => {
      if (!results?.length) return;
      const item = results[0];
      if (item.state === 'complete')      { clearInterval(timer); callback(item); }
      else if (item.state === 'interrupted') { clearInterval(timer); callback(null); }
    });
  }, interval);
}

function notifyTab(tabId, message) {
  console.log('[ProValuate BG] Sending to tab', tabId, ':', message.action, message.message || '');
  chrome.tabs.sendMessage(tabId, message, () => {
    if (chrome.runtime.lastError) {
      console.log('[ProValuate BG] Send error:', chrome.runtime.lastError.message);
    }
  });
}

// Listen for messages from content script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {

  // --- Get config (credentials come from cookie sync after user logs in on dashboard) ---
  if (request.action === 'li_getConfig') {
    chrome.storage.sync.get(['li_apiBase', 'li_companyId', 'li_userId', 'li_websiteUrl'], (result) => {
      sendResponse({
        apiBase:    decodeValue(result.li_apiBase)    || DEFAULT_API_BASE,
        companyId:  decodeValue(result.li_companyId) || '',
        userId:     decodeValue(result.li_userId)     || '',
        websiteUrl: decodeValue(result.li_websiteUrl) || DEFAULT_WEBSITE_URL
      });
    });
    return true;
  }

  // --- Save config (popup saves only API base and dashboard URL; credentials are synced via cookies) ---
  if (request.action === 'li_saveConfig') {
    chrome.storage.sync.get(['li_apiBase', 'li_websiteUrl', 'li_companyId', 'li_userId'], (existing) => {
      chrome.storage.sync.set({
        li_apiBase:    request.apiBase    ? request.apiBase.replace(/\/$/, '') : (decodeValue(existing.li_apiBase) || DEFAULT_API_BASE),
        li_websiteUrl: request.websiteUrl ? request.websiteUrl.replace(/\/$/, '') : (decodeValue(existing.li_websiteUrl) || DEFAULT_WEBSITE_URL),
        li_companyId:  existing.li_companyId ?? '',
        li_userId:     existing.li_userId ?? ''
      }, () => {
        console.log('[ProValuate LinkedIn] Config saved');
        sendResponse({ success: true });
      });
    });
    return true;
  }

  // --- Sync credentials from dashboard cookies (e.g. when user just logged in) ---
  if (request.action === 'li_syncCookies') {
    syncCookiesToStorage('manual').then((ok) => {
      sendResponse({ success: ok });
    });
    return true;
  }

  // --- Fetch JDs ---
  if (request.action === 'li_fetchJDs') {
    const url = `${request.apiBase}/api/job_descriptions?company_id=${request.companyId}`;
    fetch(url)
      .then(r => r.json())
      .then(data => sendResponse({ success: true, data }))
      .catch(err => sendResponse({ success: false, error: err.message }));
    return true;
  }

  // --- Fetch Criteria (optional jd_id to filter by job description) ---
  if (request.action === 'li_fetchCriteria') {
    let url = `${request.apiBase}/api/criteria?company_id=${request.companyId}`;
    if (request.jdId) {
      url += `&jd_id=${encodeURIComponent(request.jdId)}`;
    }
    fetch(url)
      .then(r => r.json())
      .then(data => sendResponse({ success: true, data }))
      .catch(err => sendResponse({ success: false, error: err.message }));
    return true;
  }

  // --- Upload profile text as .txt file to /cv/upload ---
  if (request.action === 'li_uploadProfile') {
    const { apiBase, profileText, candidateName, jdId, criteriaId, userId, companyId } = request;

    // Convert text to a Blob, then to a File-like FormData entry
    const blob = new Blob([profileText], { type: 'text/plain' });
    const fileName = `${candidateName.replace(/[^a-zA-Z0-9 ]/g, '_')}_LinkedIn.txt`;

    // We can't use File constructor in service worker directly with FormData fetch,
    // so we base64-encode and POST as JSON to a helper, OR we use a data URL approach.
    // Easiest: send as multipart via fetch with Blob directly (works in MV3 service worker)
    const formData = new FormData();
    formData.append('file', blob, fileName);
    formData.append('jd_id', jdId || '');
    formData.append('criteria_id', criteriaId || '');
    formData.append('user_id', userId || '');
    formData.append('company_id', companyId || '');
    formData.append('candidate_name', candidateName || '');

    fetch(`${apiBase}/cv/upload`, {
      method: 'POST',
      body: formData
    })
      .then(r => r.json())
      .then(data => sendResponse({ success: true, data }))
      .catch(err => sendResponse({ success: false, error: err.message }));

    return true;
  }

  // --- Analyze uploaded resume ---
  if (request.action === 'li_analyzeResume') {
    const { apiBase, resumeUrl, jdId, criteriaId, userId, companyId } = request;

    fetch(`${apiBase}/cv/analyze_resumes`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        resume_urls: [resumeUrl],
        jd_id: jdId,
        criteria_id: criteriaId,
        user_id: userId,
        company_id: companyId
      })
    })
      .then(r => r.json())
      .then(data => sendResponse({ success: true, data }))
      .catch(err => sendResponse({ success: false, error: err.message }));

    return true;
  }

  if (request.action === 'li_registerAssessment') {
    pendingAssessment = {
      tabId:         sender.tab.id,
      jdId:          request.jdId,
      criteriaId:    request.criteriaId,
      userId:        request.userId,
      companyId:     request.companyId,
      apiBase:       request.apiBase,
      websiteUrl:    request.websiteUrl,
      candidateName: request.candidateName
    };
    sendResponse({ success: true });
    return true;
  }

  if (request.action === 'li_cancelAssessment') {
    pendingAssessment = null;
    sendResponse({ success: true });
    return true;
  }
});

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.get(['li_apiBase', 'li_websiteUrl'], (r) => {
    const data = {
      li_apiBase:    decodeValue(r.li_apiBase)    || DEFAULT_API_BASE,
      li_websiteUrl: decodeValue(r.li_websiteUrl) || DEFAULT_WEBSITE_URL
    };
    if (!r.li_apiBase) chrome.storage.sync.set(data, () => syncCookiesToStorage('install'));
    else syncCookiesToStorage('install');
  });
});

setInterval(() => syncCookiesToStorage('interval'), 5 * 60 * 1000);
syncCookiesToStorage('startup');

chrome.cookies.onChanged.addListener((changeInfo) => {
  if (!changeInfo?.cookie || !LI_COOKIE_NAMES.has(changeInfo.cookie.name)) return;
  syncCookiesToStorage('cookieChanged');
});

console.log('[ProValuate LinkedIn] Background service worker started');
