// ProValuate LinkedIn Extension - Popup Script
// Minimal popup: silent cookie sync on open, description only

document.addEventListener('DOMContentLoaded', () => {
  try {
    chrome.runtime.sendMessage({ action: 'li_syncCookies' }, () => {});
  } catch (e) {}
});
