// ProValuate LinkedIn Extension - Content Script (PDF-based flow)
// Runs on linkedin.com/in/* pages

(function () {
  'use strict';

  if (window.__provaluateLinkedInInjected) return;
  window.__provaluateLinkedInInjected = true;

  // Stored when assessment starts — used to show success when "Processing complete!" arrives (in case li_assessmentComplete is lost)
  let pendingSuccessData = null;

  // ─────────────────────────────────────────────
  // HELPERS
  // ─────────────────────────────────────────────

  function clean(str) {
    if (!str) return '';
    return str.replace(/\s+/g, ' ').trim();
  }

  function getNameFromTitle() {
    const t = document.title || '';
    if (!t.includes('|')) return 'Unknown';
    const part = t.split('|')[0].trim();
    return part.includes(' - ') ? part.split(' - ')[0].trim() : part;
  }

  function findMoreButton() {
    const candidates = document.querySelectorAll('button[aria-label*="More"], button[aria-label*="more"]');
    for (const btn of candidates) {
      const label = (btn.getAttribute('aria-label') || '').toLowerCase();
      if (label.includes('more')) return btn;
    }
    for (const btn of document.querySelectorAll('button')) {
      if (clean(btn.innerText || '').toLowerCase() === 'more') return btn;
    }
    return null;
  }

  function findSaveToPdfItem() {
    const items = document.querySelectorAll('div[role="menuitem"], li[role="menuitem"]');
    for (const item of items) {
      if (clean(item.innerText || '').toLowerCase().includes('save to pdf')) return item;
    }
    return null;
  }

  async function clickSaveToPdf() {
    return new Promise(async (resolve, reject) => {
      let item = findSaveToPdfItem();
      if (item) { item.click(); resolve(true); return; }

      const moreBtn = findMoreButton();
      if (!moreBtn) { reject(new Error('Could not find the "More" menu button')); return; }

      moreBtn.click();
      let attempts = 0;
      const check = setInterval(() => {
        attempts++;
        item = findSaveToPdfItem();
        if (item) {
          clearInterval(check);
          setTimeout(() => { item.click(); resolve(true); }, 150);
          return;
        }
        if (attempts >= 20) {
          clearInterval(check);
          moreBtn.click(); // close menu
          reject(new Error('Could not find "Save to PDF" in menu'));
        }
      }, 100);
    });
  }

  // ─────────────────────────────────────────────
  // UI HELPERS
  // ─────────────────────────────────────────────

  function setStatus(msg, type) {
    const el = document.getElementById('pv-li-status');
    if (!el) return;
    el.textContent = msg;
    el.className = `pv-li-status ${type || 'pv-li-info'}`;
    el.classList.remove('pv-li-hidden');
  }

  function hideStatus() {
    const el = document.getElementById('pv-li-status');
    if (el) el.classList.add('pv-li-hidden');
  }

  // ─────────────────────────────────────────────
  // NOTIFICATION BAR (top-left, persists after modal closes)
  // ─────────────────────────────────────────────

  function showNotificationBar(candidateName, message) {
    // Remove any existing bar
    const existing = document.getElementById('pv-li-notify-bar');
    if (existing) existing.remove();

    const bar = document.createElement('div');
    bar.id = 'pv-li-notify-bar';
    bar.innerHTML = `
      <div class="pv-li-bar-spinner"></div>
      <span id="pv-li-bar-msg">${message || 'Processing ' + candidateName + '...'}</span>
      <button id="pv-li-bar-dismiss" title="Dismiss">✕</button>
    `;
    document.body.appendChild(bar);
    document.getElementById('pv-li-bar-dismiss').addEventListener('click', () => bar.remove());
  }

  function updateNotificationBar(message, type) {
    const bar = document.getElementById('pv-li-notify-bar');
    if (!bar) return;

    // Update text
    const msg = document.getElementById('pv-li-bar-msg');
    if (msg) msg.textContent = message;

    if (type === 'success') {
      // Replace entire inner HTML — no fragile querySelector hunting
      bar.innerHTML = `
      <span style="font-size:15px;font-weight:700;">✓</span>
      <span id="pv-li-bar-msg">${message}</span>
      <button id="pv-li-bar-dismiss" title="Dismiss">✕</button>
    `;
      bar.style.background = '#15803d';
      document.getElementById('pv-li-bar-dismiss')?.addEventListener('click', () => bar.remove());
      setTimeout(() => { if (bar.parentNode) bar.remove(); }, 6000);

    } else if (type === 'error') {
      bar.innerHTML = `
      <span style="font-size:15px;font-weight:700;">✕</span>
      <span id="pv-li-bar-msg">${message}</span>
      <button id="pv-li-bar-dismiss" title="Dismiss">✕</button>
    `;
      bar.style.background = '#b91c1c';
      document.getElementById('pv-li-bar-dismiss')?.addEventListener('click', () => bar.remove());
      setTimeout(() => { if (bar.parentNode) bar.remove(); }, 7000);
    }
  }

  // ─────────────────────────────────────────────
  // FLOATING BUTTON
  // ─────────────────────────────────────────────

  function injectButton() {
    if (document.getElementById('pv-li-assess-btn')) return;
    const btn = document.createElement('div');
    btn.id = 'pv-li-assess-btn';
    btn.className = 'pv-li-favicon-btn';
    const faviconUrl = chrome.runtime.getURL('favicon.png');
    btn.innerHTML = `<img src="${faviconUrl}" alt="ProValuate" />`;
    btn.title = 'Assess on ProValuate';
    btn.addEventListener('click', openAssessModal);
    document.body.appendChild(btn);
  }

  // ─────────────────────────────────────────────
  // MODAL
  // ─────────────────────────────────────────────

  function openAssessModal() {
    if (document.getElementById('pv-li-modal-overlay')) return;

    const candidateName = getNameFromTitle();

    const overlay = document.createElement('div');
    overlay.id = 'pv-li-modal-overlay';
    overlay.innerHTML = `
      <div id="pv-li-modal">
        <div id="pv-li-modal-header">
          <span id="pv-li-modal-title">Assess on ProValuate</span>
          <button id="pv-li-modal-close" title="Close">✕</button>
        </div>
        <div id="pv-li-modal-body">
          <div id="pv-li-login-message" class="pv-li-login-warning">
            <p>First-time setup: Please login to <a id="pv-li-login-link" href="#" target="_blank">ProValuate</a> to sync your credentials with this extension. This is only required once.</p>
          </div>
          <div id="pv-li-profile-preview">
            <div class="pv-li-label">Candidate</div>
            <div id="pv-li-candidate-name" class="pv-li-value">${candidateName}</div>
          </div>
          <div class="pv-li-field">
            <label class="pv-li-label" for="pv-li-jd-select">Job Description</label>
            <div class="pv-li-select-row">
              <select id="pv-li-jd-select" class="pv-li-select">
                <option value="">Loading...</option>
              </select>
              <a id="pv-li-new-jd-link" href="#" target="_blank" class="pv-li-new-link" title="Create new Job Description">+ New JD</a>
            </div>
          </div>
          <div class="pv-li-field">
            <label class="pv-li-label" for="pv-li-criteria-select">Criteria (Optional)</label>
            <div class="pv-li-select-row">
              <select id="pv-li-criteria-select" class="pv-li-select">
                <option value="">Loading...</option>
              </select>
              <a id="pv-li-new-criteria-link" href="#" target="_blank" class="pv-li-new-link" title="Create new Evaluation Criteria">+ New Criteria</a>
            </div>
          </div>
          <div id="pv-li-status" class="pv-li-status pv-li-hidden"></div>
          <button id="pv-li-assess-btn-action" class="pv-li-primary-btn" disabled>
            Assess Candidate
          </button>
        </div>
      </div>
    `;

    overlay.addEventListener('click', (e) => { if (e.target === overlay) closeModal(); });
    document.body.appendChild(overlay);
    document.getElementById('pv-li-modal-close')?.addEventListener('click', closeModal);

    initModal(candidateName);
  }

  function closeModal() {
    const el = document.getElementById('pv-li-modal-overlay');
    if (el) el.remove();
    chrome.runtime.sendMessage({ action: 'li_cancelAssessment' });
  }

  // Closes modal WITHOUT cancelling the background assessment
  function closeModalSilently() {
    const el = document.getElementById('pv-li-modal-overlay');
    if (el) el.remove();
  }

  // ─────────────────────────────────────────────
  // MODAL INIT / DATA LOADING
  // ─────────────────────────────────────────────

  function checkReady() {
    const v = document.getElementById('pv-li-jd-select')?.value;
    const btn = document.getElementById('pv-li-assess-btn-action');
    if (btn) btn.disabled = !v;
  }

  function initModal(candidateName) {
    function tryLoadConfig(done) {
      chrome.runtime.sendMessage({ action: 'li_getConfig' }, (config) => {
        if (chrome.runtime.lastError) {
          if (done) done(null);
          return;
        }
        done(config);
      });
    }

    // Sync credentials from dashboard when modal opens so JD/criteria grids match current login (like ProValuate)
    chrome.runtime.sendMessage({ action: 'li_syncCookies' }, () => {
      tryLoadConfig((config) => {
      if (!config) {
        setStatus('Extension error.', 'pv-li-warn');
        return;
      }
      const websiteUrl = (config.websiteUrl || '').replace(/\/$/, '');
      const loginLink = document.getElementById('pv-li-login-link');
      const newJdLink = document.getElementById('pv-li-new-jd-link');
      const newCriteriaLink = document.getElementById('pv-li-new-criteria-link');
      if (loginLink && websiteUrl) loginLink.href = websiteUrl;
      if (newJdLink && websiteUrl) newJdLink.href = websiteUrl + '/dashboard?section=job-upload';
      if (newCriteriaLink && websiteUrl) newCriteriaLink.href = websiteUrl + '/dashboard?section=evaluation-criteria';

      if (!config.companyId || !config.userId) {
        chrome.runtime.sendMessage({ action: 'li_syncCookies' }, () => {});
        let attempts = 0;
        const maxAttempts = 10;
        const retry = setInterval(() => {
          attempts++;
          tryLoadConfig((retryConfig) => {
            if (!retryConfig) return;
            if (retryConfig.companyId && retryConfig.userId) {
              clearInterval(retry);
              proceedWithConfig(retryConfig, candidateName);
            } else if (attempts >= maxAttempts) {
              clearInterval(retry);
              setStatus('Log in via the link above; credentials will sync automatically.', 'pv-li-info');
            }
          });
        }, 1000);
        return;
      }

      proceedWithConfig(config, candidateName);
      });
    });
  }

  function proceedWithConfig(config, candidateName) {
      chrome.runtime.sendMessage({ action: 'li_fetchJDs', apiBase: config.apiBase, companyId: config.companyId }, (res) => {
        const sel = document.getElementById('pv-li-jd-select');
        if (!sel) return;
        if (res?.success) {
          const jds = res.data?.data || res.data || [];
          sel.innerHTML = '<option value="">-- Select Job Description --</option>';
          jds.forEach(jd => {
            const o = document.createElement('option');
            o.value = jd.jd_id;
            o.textContent = jd.title || jd.jd_id;
            sel.appendChild(o);
          });
          if (jds.length === 0) sel.innerHTML = '<option value="">No JDs found</option>';
        } else {
          sel.innerHTML = '<option value="">⚠️ Failed to load — check connection.</option>';
        }
        checkReady();
      });

      // Criteria: show only when a JD is selected — load criteria for that JD
      const criteriaSelect = document.getElementById('pv-li-criteria-select');
      if (criteriaSelect) {
        criteriaSelect.innerHTML = '<option value="">-- Select a JD first --</option>';
        criteriaSelect.disabled = true;
      }

      function loadCriteriaForJd(jdId) {
        const sel = document.getElementById('pv-li-criteria-select');
        if (!sel) return;
        if (!jdId) {
          sel.innerHTML = '<option value="">-- Select a JD first --</option>';
          sel.disabled = true;
          return;
        }
        sel.disabled = true;
        sel.innerHTML = '<option value="">Loading criteria...</option>';
        chrome.runtime.sendMessage({
          action: 'li_fetchCriteria',
          apiBase: config.apiBase,
          companyId: config.companyId,
          jdId: jdId
        }, (res) => {
          sel.innerHTML = '<option value="">-- None --</option>';
          sel.disabled = false;
          if (res?.success) {
            const list = res.data?.data || res.data || [];
            list.forEach(c => {
              const o = document.createElement('option');
              o.value = c.criteria_id;
              o.textContent = c.criteria_name || c.criteria_id;
              sel.appendChild(o);
            });
          }
        });
      }

      document.getElementById('pv-li-jd-select')?.addEventListener('change', function () {
        const jdId = this.value || '';
        loadCriteriaForJd(jdId);
        checkReady();
      });
      document.getElementById('pv-li-assess-btn-action')?.addEventListener('click', () => runAssess(candidateName, config));
  }

  // ─────────────────────────────────────────────
  // RUN ASSESSMENT (PDF FLOW)
  // ─────────────────────────────────────────────

  async function runAssess(candidateName, config) {
    const jdId       = document.getElementById('pv-li-jd-select')?.value;
    const criteriaId = document.getElementById('pv-li-criteria-select')?.value || '';
    if (!jdId) { setStatus('Please select a Job Description.', 'pv-li-warn'); return; }

    const btn = document.getElementById('pv-li-assess-btn-action');
    if (btn) { btn.disabled = true; btn.textContent = 'Opening PDF menu...'; }

    chrome.runtime.sendMessage({
      action: 'li_registerAssessment',
      jdId, criteriaId,
      userId:        config.userId,
      companyId:     config.companyId,
      apiBase:       config.apiBase,
      websiteUrl:    config.websiteUrl,
      candidateName: candidateName
    }, async (res) => {
      if (!res?.success) {
        setStatus('❌ Could not register assessment.', 'pv-li-error');
        if (btn) { btn.disabled = false; btn.textContent = 'Assess Candidate'; }
        return;
      }
      try {
        pendingSuccessData = { websiteUrl: config.websiteUrl, candidateName };
        await clickSaveToPdf();

        // Close modal silently (does NOT cancel the background assessment)
        // then immediately show notification bar so user knows it's running
        closeModalSilently();
        showNotificationBar(candidateName, 'PDF generating… please wait');

      } catch (err) {
        // clickSaveToPdf failed — cancel everything and show error in modal
        pendingSuccessData = null;
        setStatus('❌ ' + err.message, 'pv-li-error');
        if (btn) { btn.disabled = false; btn.textContent = 'Assess Candidate'; }
        chrome.runtime.sendMessage({ action: 'li_cancelAssessment' });
      }
    });
  }

  // ─────────────────────────────────────────────
  // COMPLETION TOAST
  // ─────────────────────────────────────────────

  function showCompletionToast(candidateName, websiteUrl) {
    const toast = document.createElement('div');
    toast.id = 'pv-li-completion-toast';
    toast.className = 'pv-li-toast';
    toast.innerHTML = `
      <span class="pv-li-toast-icon">✓</span>
      <span><strong>${candidateName}</strong> — Profile assessed successfully. <a href="${websiteUrl}" target="_blank">Open Dashboard</a></span>
    `;
    document.body.appendChild(toast);
    setTimeout(() => toast.classList.add('pv-li-toast-visible'), 10);
    setTimeout(() => {
      toast.classList.remove('pv-li-toast-visible');
      setTimeout(() => toast.remove(), 300);
    }, 5000);
  }

  // ─────────────────────────────────────────────
  // BACKGROUND MESSAGE HANDLER
  // ─────────────────────────────────────────────

  chrome.runtime.onMessage.addListener((msg) => {
    console.log('[ProValuate] Message received:', msg.action, msg.message || '');
    console.log('[ProValuate] Bar exists:', !!document.getElementById('pv-li-notify-bar'));
    console.log('[ProValuate] pendingSuccessData:', pendingSuccessData);

    if (msg.action === 'li_statusUpdate') {
      const bar = document.getElementById('pv-li-notify-bar');
      if (bar) {
        updateNotificationBar(msg.message);
      } else {
        setStatus(msg.message, 'pv-li-info');
      }
      // Completion is handled by li_assessmentComplete
    }

    if (msg.action === 'li_assessmentError') {
      pendingSuccessData = null;
      const bar = document.getElementById('pv-li-notify-bar');
      if (bar) {
        updateNotificationBar('Error: ' + msg.error, 'error');
      } else {
        setStatus('❌ ' + msg.error, 'pv-li-error');
        const btn = document.getElementById('pv-li-assess-btn-action');
        if (btn) { btn.disabled = false; btn.textContent = 'Assess Candidate'; }
      }
    }

    if (msg.action === 'li_assessmentComplete') {
      const url  = msg.websiteUrl  || (pendingSuccessData && pendingSuccessData.websiteUrl);
      const name = msg.candidateName || (pendingSuccessData && pendingSuccessData.candidateName);
      pendingSuccessData = null;
      if (name) updateNotificationBar(`✓ ${name} — sent for analysis. View on dashboard.`, 'success');
      // Bar is enough, no need for double notification (toast removed)
    }
  });

  // ─────────────────────────────────────────────
  // INIT + SPA NAVIGATION WATCHER
  // ─────────────────────────────────────────────

  function tryInject() {
    if (!window.location.pathname.startsWith('/in/')) return;
    injectButton();
  }

  let lastUrl = location.href;
  new MutationObserver(() => {
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      const old = document.getElementById('pv-li-assess-btn');
      if (old) old.remove();
      window.__provaluateLinkedInInjected = false;
      setTimeout(tryInject, 2000);
    }
  }).observe(document.body, { childList: true, subtree: true });

  setTimeout(tryInject, 2000);

})();

