# ProValuate – LinkedIn Assessor Extension

Assess LinkedIn profiles **directly from the browser** — no PDF download, no file upload, no manual steps.

## How It Works

1. Extension content script runs on `linkedin.com/in/*`
2. Scrapes visible profile data (name, headline, experience, education, skills, certifications)
3. Formats it as structured plain text
4. Sends it to your existing `/cv/upload` endpoint as a `.txt` file
5. Triggers `/cv/analyze_resumes` — same pipeline as Gmail resumes

**Zero backend changes needed.**

---

## File Structure

```
linkedin-extension/
├── manifest.json       ← Extension manifest (standalone, won't affect Gmail extension)
├── li_background.js    ← Service worker (config storage + API calls)
├── li_content.js       ← Runs on LinkedIn pages (scraper + UI button + modal)
├── li_styles.css       ← Styles for floating button and modal
├── li_popup.html       ← Extension popup (settings UI)
├── li_popup.js         ← Popup logic
└── favicon.png         ← Copy from your main extension folder
```

> ⚠️ Copy `favicon.png` from your existing ProValuate extension folder into this folder before loading.

---

## Local Setup

### 1. Copy favicon
```
cp ../ProValuate-Extension/favicon.png ./linkedin-extension/favicon.png
```

### 2. Load in Chrome
1. Go to `chrome://extensions/`
2. Enable **Developer mode**
3. Click **Load unpacked**
4. Select the `linkedin-extension/` folder

### 3. Configure
1. Log in to the ProValuate dashboard once: **https://provaluate.aitamate.com**
2. Credentials (Company ID, User ID) sync automatically from the dashboard; no manual entry needed.
3. Default backend: **https://flask-6421997997235322.kloudbeansite.com** — same as the ProValuate extension.

---

## Usage

1. Open any LinkedIn profile (e.g. `linkedin.com/in/jrohit123`)
2. A blue **"Assess on ProValuate"** button appears at the bottom-right
3. Click it → modal opens, candidate name auto-detected
4. Select Job Description (and optionally criteria)
5. Click **Assess Candidate**
6. Done — view results on your dashboard

---

## What Gets Scraped

| Field | Source |
|---|---|
| Name | `h1.text-heading-xlarge` |
| Headline | `.text-body-medium.break-words` |
| Location | `.pv-top-card--list-bullet` |
| About | `#about` section |
| Experience | `#experience` section list items |
| Education | `#education` section list items |
| Skills | `#skills` section list items |
| Certifications | `#licenses_and_certifications` section |

---

## API Flow

```
li_content.js  →  scrapeProfile()
               →  formatProfileAsText()
               →  chrome.runtime.sendMessage('li_uploadProfile')
                         ↓
               li_background.js  →  POST /cv/upload  (text/plain .txt file)
                                            ↓
                                  returns { file_url }
                                            ↓
               li_background.js  →  POST /cv/analyze_resumes
                                            ↓
                                  Assessment complete ✓
```

---

## Troubleshooting

**Button not appearing?**
- Make sure you're on a `linkedin.com/in/` profile URL (not feed, search, etc.)
- Wait 2 seconds for the page to fully load, then refresh

**"Could not load JDs" in modal?**
- Log in to the ProValuate dashboard (https://provaluate.aitamate.com) so credentials sync; then reopen the modal.
- Check your connection; default API is https://flask-6421997997235322.kloudbeansite.com

**Scraping missing data?**
- LinkedIn's DOM selectors can change. If sections are empty, scroll down on the profile to fully load them before clicking Assess
- Open DevTools console on the LinkedIn page and look for `[ProValuate]` logs

**Upload fails?**
- Check Python backend logs — the `.txt` file type must be in `allowed_file()` in `cv_analyzer.py`
- Verify CORS allows `chrome-extension://` origins (already handled in your `app.py`)

---

## Notes

- This extension is **completely independent** of the Gmail extension — different manifest, different service worker, different content scripts
- Both can be loaded in Chrome simultaneously with no conflicts
- LinkedIn profiles are sent as `.txt` files, which your backend already supports
