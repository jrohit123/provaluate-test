(function () {
  // Popup only shows instructions; connect link is in the modal (content.js).
})();
