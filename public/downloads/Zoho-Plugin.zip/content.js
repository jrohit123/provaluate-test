// ProValuate Zoho Add-on - content script for mail.zoho.com / mail.zoho.in
(function () {
  const STORAGE_KEYS = { apiBase: 'provaluate_api_base', companyId: 'provaluate_company_id', userId: 'provaluate_user_id' };

  function getSettings(cb) {
    chrome.storage.sync.get([STORAGE_KEYS.apiBase, STORAGE_KEYS.companyId, STORAGE_KEYS.userId], function (r) {
      cb({
        apiBase: (r[STORAGE_KEYS.apiBase] || '').replace(/\/$/, '') || 'https://flask-6421998707235322.kloudbeansite.com',
        companyId: r[STORAGE_KEYS.companyId] || '',
        userId: r[STORAGE_KEYS.userId] || ''
      });
    });
  }

  // Try to get current message ID from Zoho Mail page (URL hash/path or data attributes)
  function getMessageIdFromPage() {
    var href = window.location.href || '';
    var hash = window.location.hash || '';
    // Common patterns: #/mail/.../messageId or path with message id (long number)
    var match = (href + hash).match(/(?:messageId|message_id|msgid|messages?)[\/=](\d{10,})/i);
    if (match) return match[1];
    match = (hash).match(/\/(\d{15,})\b/);
    if (match) return match[1];
    var el = document.querySelector('[data-message-id], [data-messageid], [data-msg-id]');
    if (el) {
      var id = el.getAttribute('data-message-id') || el.getAttribute('data-messageid') || el.getAttribute('data-msg-id');
      if (id) return id;
    }
    return null;
  }

  function showButton() {
    if (document.getElementById('provaluate-zoho-btn')) return;
    var btn = document.createElement('button');
    btn.id = 'provaluate-zoho-btn';
    btn.type = 'button';
    btn.title = 'ProValuate – Assess Resumes';
    try {
      var img = document.createElement('img');
      img.src = chrome.runtime.getURL('favicon.png');
      img.alt = 'ProValuate';
      img.className = 'provaluate-zoho-btn-icon';
      btn.appendChild(img);
    } catch (e) {}
    btn.onclick = openModal;
    document.body.appendChild(btn);
  }

  function openModal() {
    getSettings(function (settings) {
      if (!settings.userId || !settings.companyId) {
        alert('Credentials not synced. Log in to ProValuate in this browser (open https://devprovaluate.aitamate.com and sign in). The add-on will then pick up your Company ID and User ID automatically.');
        return;
      }
      var modal = document.getElementById('provaluate-zoho-modal');
      if (modal) {
        modal.classList.add('open');
        return;
      }
      var connectUrl = settings.apiBase + '/api/zoho/register-start' + (settings.userId ? '?user_id=' + encodeURIComponent(settings.userId) : '');
      modal = document.createElement('div');
      modal.id = 'provaluate-zoho-modal';
      modal.innerHTML = '<div class="modal-box">' +
        '<button type="button" class="pv-zoho-modal-close" id="pv-zoho-close" aria-label="Close">×</button>' +
        '<h3>ProValuate – Assess from Zoho Mail</h3>' +
        '<p class="hint">Connect your Zoho Mail account once <a href="' + connectUrl + '" target="_blank" rel="noopener" class="pv-zoho-connect-link">Connect Zoho Mail</a>, then assess resume attachments from this add-on.</p>' +
        '<button type="button" id="pv-zoho-load">Load attachments</button>' +
        '<div id="pv-zoho-attachment-list"></div>' +
        '<label>Job description</label><select id="pv-zoho-jd"></select>' +
        '<label>Criteria</label><select id="pv-zoho-criteria"></select>' +
        '<button type="button" id="pv-zoho-assess">Assess Resumes</button>' +
        '<p class="status" id="pv-zoho-status"></p>' +
        '</div>';
      modal.classList.add('open');
      document.body.appendChild(modal);

      document.getElementById('pv-zoho-close').onclick = function () { modal.classList.remove('open'); };
      document.getElementById('pv-zoho-load').onclick = function () { loadAttachments(settings); };
      document.getElementById('pv-zoho-assess').onclick = function () { runAssess(settings); };

      var jdSelect = document.getElementById('pv-zoho-jd');
      var criteriaSelect = document.getElementById('pv-zoho-criteria');
      if (criteriaSelect) {
        criteriaSelect.disabled = true;
      }

      loadJobDescriptions(settings, function (list) {
        var sel = jdSelect;
        sel.innerHTML = '<option value="">-- Select JD --</option>';
        (list || []).forEach(function (jd) {
          var opt = document.createElement('option');
          opt.value = jd.jd_id || jd.id || '';
          opt.textContent = jd.title || jd.jd_id || 'Untitled';
          sel.appendChild(opt);
        });
      });
      loadCriteria(settings, null, function (list) {
        var sel = criteriaSelect;
        sel.innerHTML = '<option value="">-- Select criteria --</option>';
        (list || []).forEach(function (c) {
          var opt = document.createElement('option');
          opt.value = c.criteria_id || c.id || '';
          opt.textContent = c.criteria_name || c.criteria_id || 'Untitled';
          sel.appendChild(opt);
        });
        sel.disabled = false;
      });

      // When JD changes, reload criteria filtered by that JD (or default when blank)
      if (jdSelect && criteriaSelect) {
        jdSelect.onchange = function () {
          var jdId = jdSelect.value || '';
          criteriaSelect.disabled = true;
          criteriaSelect.innerHTML = '<option value="">Loading criteria...</option>';
          loadCriteria(settings, jdId || null, function (list) {
            criteriaSelect.innerHTML = '<option value="">-- Select criteria --</option>';
            (list || []).forEach(function (c) {
              var opt = document.createElement('option');
              opt.value = c.criteria_id || c.id || '';
              opt.textContent = c.criteria_name || c.criteria_id || 'Untitled';
              criteriaSelect.appendChild(opt);
            });
            criteriaSelect.disabled = false;
          });
        };
      }
    });
  }

  function setStatus(msg, isError) {
    var el = document.getElementById('pv-zoho-status');
    if (el) { el.textContent = msg || ''; el.style.color = isError ? '#c00' : '#060'; }
  }

  function loadJobDescriptions(settings, cb) {
    var url = settings.apiBase + '/api/job_descriptions?company_id=' + encodeURIComponent(settings.companyId);
    fetch(url, { method: 'GET', headers: { 'Content-Type': 'application/json' } })
      .then(function (r) { return r.json(); })
      .then(function (data) { cb((data && data.data) ? data.data : []); })
      .catch(function () { cb([]); });
  }

  function loadCriteria(settings, jdId, cb) {
    var url = settings.apiBase + '/api/criteria?company_id=' + encodeURIComponent(settings.companyId);
    if (jdId) url += '&jd_id=' + encodeURIComponent(jdId);
    fetch(url, { method: 'GET', headers: { 'Content-Type': 'application/json' } })
      .then(function (r) { return r.json(); })
      .then(function (data) { cb((data && data.data) ? data.data : []); })
      .catch(function () { cb([]); });
  }

  var cachedList = null; // { messageId, account_id, folder_id, attachments }

  function loadAttachments(settings) {
    var messageId = getMessageIdFromPage();
    if (!messageId) {
      setStatus('Could not detect current email. Open an email with resume attachments and try again.', true);
      return;
    }
    setStatus('Loading...');
    var url = settings.apiBase + '/api/zoho/list-attachments';
    fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ user_id: settings.userId, message_id: messageId })
    })
      .then(function (r) { return r.json().then(function (data) { return { ok: r.ok, data: data }; }); })
      .then(function (result) {
        if (!result.ok) {
          setStatus(result.data && result.data.error ? result.data.error : 'Failed to load attachments', true);
          return;
        }
        var att = (result.data && result.data.attachments) || [];
        cachedList = {
          messageId: messageId,
          account_id: result.data.account_id,
          folder_id: result.data.folder_id,
          attachments: att
        };
        var listEl = document.getElementById('pv-zoho-attachment-list');
        listEl.innerHTML = '';
        if (att.length === 0) {
          listEl.textContent = 'No resume attachments (.pdf, .doc, .docx, .txt) in this email.';
          setStatus('', false);
          return;
        }
        att.forEach(function (a) {
          var label = document.createElement('label');
          label.className = 'pv-zoho-attachment-item';
          var cb = document.createElement('input');
          cb.type = 'checkbox';
          cb.className = 'pv-zoho-attachment-checkbox';
          cb.value = a.id;
          cb.checked = true;
          var span = document.createElement('span');
          span.textContent = (a.name || a.id || 'Attachment');
          label.appendChild(cb);
          label.appendChild(span);
          listEl.appendChild(label);
        });
        setStatus('Loaded ' + att.length + ' attachment(s). Select JD and Criteria, then click Assess Resumes.', false);
      })
      .catch(function (err) {
        setStatus('Error: ' + (err && err.message ? err.message : 'Request failed'), true);
      });
  }

  function runAssess(settings) {
    var jdSel = document.getElementById('pv-zoho-jd');
    var critSel = document.getElementById('pv-zoho-criteria');
    var jdId = jdSel && jdSel.value ? jdSel.value : '';
    var criteriaId = critSel && critSel.value ? critSel.value : '';
    if (!jdId) {
      setStatus('Please select a job description.', true);
      return;
    }
    if (!cachedList || !cachedList.messageId) {
      setStatus('Please click Load attachments first.', true);
      return;
    }

    // Collect only the selected attachment IDs
    var listEl = document.getElementById('pv-zoho-attachment-list');
    var selectedIds = [];
    if (listEl) {
      var boxes = listEl.querySelectorAll('.pv-zoho-attachment-checkbox');
      boxes.forEach(function (box) {
        if (box.checked && box.value) selectedIds.push(box.value);
      });
    }
    if (!selectedIds.length) {
      setStatus('Please select at least one attachment.', true);
      return;
    }

    setStatus('Assessing...');
    var url = settings.apiBase + '/api/zoho/fetch-and-analyze';
    var body = {
      message_id: cachedList.messageId,
      jd_id: jdId,
      criteria_id: criteriaId || null,
      company_id: settings.companyId,
      user_id: settings.userId,
      account_id: cachedList.account_id,
      folder_id: cachedList.folder_id,
      attachmentIds: selectedIds
    };
    fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    })
      .then(function (r) { return r.json().then(function (data) { return { ok: r.ok, data: data }; }); })
      .then(function (result) {
        if (!result.ok) {
          setStatus(result.data && result.data.error ? result.data.error : 'Assessment failed', true);
          return;
        }
        var d = result.data;
        var ok = (d && d.successful_analyses) ? d.successful_analyses : 0;
        var fail = (d && d.failed_analyses) ? d.failed_analyses : 0;
        setStatus('Done. ' + ok + ' analyzed, ' + fail + ' failed.', false);
      })
      .catch(function (err) {
        setStatus('Error: ' + (err && err.message ? err.message : 'Request failed'), true);
      });
  }

  function init() {
    showButton();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
