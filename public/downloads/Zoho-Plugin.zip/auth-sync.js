// Sync ProValuate credentials from dashboard (localStorage) to chrome.storage when user logs in.
// Same keys as Gmail extension so credentials work across ProValuate extensions.
(function () {
  const STORAGE_KEYS = {
    apiBase: 'provaluate_api_base',
    companyId: 'provaluate_company_id',
    userId: 'provaluate_user_id',
    websiteUrl: 'provaluate_website_url',
  };

  let lastSnapshot = null;

  function decodeValue(value) {
    if (value == null) return value;
    try {
      return decodeURIComponent(value);
    } catch (error) {
      return value;
    }
  }

  function readCredentialSnapshot() {
    try {
      return {
        apiBase: decodeValue(localStorage.getItem(STORAGE_KEYS.apiBase) || ''),
        companyId: decodeValue(localStorage.getItem(STORAGE_KEYS.companyId) || ''),
        userId: decodeValue(localStorage.getItem(STORAGE_KEYS.userId) || ''),
        websiteUrl: decodeValue(localStorage.getItem(STORAGE_KEYS.websiteUrl) || window.location.origin),
      };
    } catch (error) {
      return null;
    }
  }

  function snapshotsEqual(a, b) {
    if (!a || !b) return false;
    return a.apiBase === b.apiBase && a.companyId === b.companyId && a.userId === b.userId;
  }

  function syncToStorage(snapshot) {
    if (!snapshot || !chrome.storage || !chrome.storage.sync) return;
    const data = {};
    if (snapshot.apiBase) data[STORAGE_KEYS.apiBase] = snapshot.apiBase;
    if (snapshot.companyId) data[STORAGE_KEYS.companyId] = snapshot.companyId;
    if (snapshot.userId) data[STORAGE_KEYS.userId] = snapshot.userId;
    if (snapshot.websiteUrl) data[STORAGE_KEYS.websiteUrl] = snapshot.websiteUrl;
    if (Object.keys(data).length > 0) {
      chrome.storage.sync.set(data);
    }
  }

  function checkAndSync() {
    var snapshot = readCredentialSnapshot();
    if (!snapshot) return;
    if (!lastSnapshot || !snapshotsEqual(snapshot, lastSnapshot)) {
      lastSnapshot = snapshot;
      syncToStorage(snapshot);
    }
  }

  checkAndSync();
  window.addEventListener('storage', function (e) {
    if (e && e.key && [STORAGE_KEYS.apiBase, STORAGE_KEYS.companyId, STORAGE_KEYS.userId].indexOf(e.key) !== -1) {
      setTimeout(checkAndSync, 50);
    }
  });
  setInterval(checkAndSync, 2000);
})();
