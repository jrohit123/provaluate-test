// ProValuate Email Plugin - Content Script
// Integrates with Gmail and Outlook for resume evaluation

class ProValuateEmailPlugin {
  constructor() {
    this.isGmail = window.location.href.includes("mail.google.com");
    this.isOutlook = window.location.href.includes("outlook.live.com") ||
      window.location.href.includes("outlook.office365.com") ||
      window.location.href.includes("outlook.office.com");

    // Get API base URL from storage or use default
    this.apiBase = null;
    this.companyId = null;
    this.userId = null;

    this.detectedResumes = [];
    this._isAssessing = false; // ✅ Flag to prevent multiple simultaneous assessments
    this._modalClosedDuringProcessing = false; // ✅ Track if modal was closed during assessment
    this._isScanning = false; // ✅ ADD: Lock to prevent multiple simultaneous scans
    this._isModalOpen = false; // ✅ ADD: Track if modal is open
    this._lastButtonClickTime = 0; // ✅ ADD: For debouncing button clicks
    this.init();
  }

  getDownloadHref(downloadLink) {
    if (!downloadLink) return '';
    if (typeof downloadLink === 'string') {
      return downloadLink;
    }

    try {
      if (downloadLink.href && typeof downloadLink.href === 'string') {
        return downloadLink.href;
      }
    } catch (error) {
      // Ignore DOM access errors
    }

    if (typeof downloadLink.getAttribute === 'function') {
      const hrefAttr = downloadLink.getAttribute('href');
      if (hrefAttr) {
        return hrefAttr;
      }
    }

    return '';
  }

  createResumeKey(resume) {
    if (!resume || !resume.fileName) {
      return 'invalid';
    }

    const href = this.getDownloadHref(resume.downloadLink);
    const attachmentSignature = href ||
      resume.element?.getAttribute?.('data-attachment-id') ||
      resume.element?.getAttribute?.('data-tooltip') ||
      resume.element?.getAttribute?.('aria-label') ||
      '';
    const messageId = resume.messageId || this.extractMessageId(resume.element || resume.downloadLink);
    const downloadUrlSignature = resume.downloadUrl || this.extractDownloadUrlAttribute(resume.element || resume.downloadLink) || '';

    return `${messageId || 'nomsg'}::${resume.platform || 'unknown'}::${resume.fileName.toLowerCase()}::${attachmentSignature || downloadUrlSignature}`;
  }

  normalizeResumeCandidate(resumeCandidate, indexHint = 0) {
    if (!resumeCandidate) return null;

    const cleanedName = this.cleanFileName(resumeCandidate.fileName || '');
    if (!cleanedName) return null;

    const platform = resumeCandidate.platform || (this.isGmail ? 'gmail' : this.isOutlook ? 'outlook' : 'unknown');
    let downloadLink = resumeCandidate.downloadLink || null;

    if (!downloadLink && resumeCandidate.element?.querySelector) {
      const inferredLink = resumeCandidate.element.querySelector('a[download], a[href*="attachment"], a[href*="download"]');
      if (inferredLink) {
        downloadLink = inferredLink;
      }
    }
    const messageId = resumeCandidate.messageId || this.extractMessageId(resumeCandidate.element || downloadLink);
    const downloadUrl = resumeCandidate.downloadUrl || this.extractDownloadUrlAttribute(resumeCandidate.element || downloadLink);

    return {
      ...resumeCandidate,
      fileName: cleanedName,
      platform,
      downloadLink,
      index: indexHint,
      messageId,
      downloadUrl
    };
  }

  updateDetectedResumes(resumes = [], options = {}) {
    const mergeExisting = options.mergeExisting || false;
    const base = mergeExisting && Array.isArray(this.detectedResumes)
      ? [...this.detectedResumes]
      : [];
    const append = Array.isArray(resumes) ? resumes : [];
    const combined = [...base, ...append];

    const unique = [];
    const seenKeys = new Set();

    combined.forEach((candidate) => {
      const normalized = this.normalizeResumeCandidate(candidate, unique.length);
      if (!normalized) return;

      const key = this.createResumeKey(normalized);
      if (seenKeys.has(key)) return;

      seenKeys.add(key);
      normalized.index = unique.length;
      unique.push(normalized);
    });

    this.detectedResumes = unique;
  }

  isElementVisible(element) {
    if (!element || element.nodeType !== Node.ELEMENT_NODE) return false;
    const style = window.getComputedStyle(element);
    if (!style || style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') {
      return false;
    }
    const rect = element.getBoundingClientRect();
    const hasSize = rect && (rect.width > 0 || rect.height > 0);
    if (hasSize) return true;
    return element.offsetParent !== null;
  }

  extractMessageId(element) {
    if (!element || typeof element.closest !== 'function') return null;
    const messageElement = element.closest('[data-message-id], [data-legacy-message-id]');
    if (!messageElement) return null;
    return messageElement.getAttribute('data-message-id') || messageElement.getAttribute('data-legacy-message-id');
  }

  getGmailThreadContainer() {
    const main = document.querySelector('div[role="main"]');
    if (!main) return null;

    const tabPanels = Array.from(main.querySelectorAll('div[role="tabpanel"]'));
    const visiblePanel = tabPanels.find(panel => this.isElementVisible(panel));
    if (visiblePanel) return visiblePanel;

    const conversation = main.querySelector('div[data-legacy-thread-id]');
    if (conversation && this.isElementVisible(conversation)) {
      return conversation;
    }

    return main;
  }

  getActiveGmailMessageElements(threadContainer) {
    if (!threadContainer) return [];

    const selector = '[data-message-id], [data-legacy-message-id]';
    const messageNodes = Array.from(threadContainer.querySelectorAll(selector))
      .filter(node => this.isElementVisible(node));

    if (messageNodes.length === 0) return [];

    // For conversational view, return ALL visible messages in the thread
    // This ensures we capture attachments from all emails in the conversation
    return messageNodes;
  }

  getGmailAttachmentContext() {
    const threadContainer = this.getGmailThreadContainer();
    if (!threadContainer) return null;

    const messageElements = this.getActiveGmailMessageElements(threadContainer);
    // Include both individual message elements AND the thread container for comprehensive scanning
    const searchScopes = messageElements.length > 0
      ? [...messageElements, threadContainer]
      : [threadContainer];
    const allowedMessageIds = new Set();
    messageElements.forEach(element => {
      const id = this.extractMessageId(element);
      if (id) {
        allowedMessageIds.add(id);
      }
    });

    // If we have message IDs, use them for filtering; otherwise, allow all (scan entire thread)
    return {
      threadContainer,
      messageElements,
      searchScopes,
      allowedMessageIds: allowedMessageIds.size > 0 ? allowedMessageIds : null // null means no filtering
    };
  }

  getOutlookEmailContext() {
    // Try to find the currently open email container
    // Outlook uses various containers for the reading pane/message view
    const readingPane = document.querySelector('[role="main"]') ||
      document.querySelector('[aria-label*="Reading"]') ||
      document.querySelector('[class*="reading"]') ||
      document.querySelector('[id*="ReadingPane"]');

    // Alternative: Find the message body container
    const messageBody = document.querySelector('[role="article"]') ||
      document.querySelector('[aria-label*="Message body"]') ||
      document.querySelector('[class*="messageBody"]');

    // Find attachment container within the current email
    const attachmentContainer = document.querySelector('[data-testid="attachmentContainer"]') ||
      document.querySelector('[aria-label="file attachments"]')?.closest('div');

    // Use the most specific container we can find
    const emailContainer = attachmentContainer || messageBody || readingPane;

    if (emailContainer) {
      console.log('✅ Found Outlook email container:', emailContainer.className?.substring(0, 50));
      return {
        emailContainer,
        searchScopes: [emailContainer]
      };
    }

    // Fallback: Try to find the active/selected email in the list
    const activeEmail = document.querySelector('[aria-selected="true"]') ||
      document.querySelector('[class*="selected"]') ||
      document.querySelector('[aria-label*="Unread"][aria-label*="attachment"]')?.closest('div[role="listitem"]');

    if (activeEmail) {
      console.log('✅ Found Outlook active email:', activeEmail.className?.substring(0, 50));
      return {
        emailContainer: activeEmail,
        searchScopes: [activeEmail]
      };
    }

    console.warn('⚠️ Could not find Outlook email container, searching entire page');
    return {
      emailContainer: null,
      searchScopes: [document]
    };
  }

  extractDownloadUrlAttribute(element) {
    if (!element || typeof element.querySelector !== 'function') return null;

    const holder = element.hasAttribute?.('download_url')
      ? element
      : element.querySelector?.('[download_url]');

    const rawUrl = holder?.getAttribute?.('download_url') ||
      element.getAttribute?.('data-download-url') ||
      element.getAttribute?.('data-url');

    return this.parseDownloadUrl(rawUrl);
  }

  parseDownloadUrl(rawUrl) {
    if (!rawUrl || typeof rawUrl !== 'string') return null;
    let candidate = rawUrl.trim().replace(/&amp;/g, '&');

    const httpIndex = candidate.indexOf('http');
    if (httpIndex > 0) {
      candidate = candidate.slice(httpIndex);
    }

    if (candidate.startsWith('//')) {
      candidate = `https:${candidate}`;
    }

    const tryParse = (value) => {
      try {
        return new URL(value).toString();
      } catch (error) {
        return null;
      }
    };

    let parsed = tryParse(candidate);
    if (parsed) return parsed;

    let truncCandidate = candidate;
    let colonIndex = truncCandidate.lastIndexOf(':');
    const schemeIndex = truncCandidate.indexOf('://');

    while (colonIndex > -1 && colonIndex > schemeIndex + 2) {
      truncCandidate = truncCandidate.slice(0, colonIndex);
      parsed = tryParse(truncCandidate);
      if (parsed) return parsed;
      colonIndex = truncCandidate.lastIndexOf(':');
    }

    return null;
  }

  async init() {
    // Load configuration from storage
    await this.loadConfig();

    // Watch for email open and attachments
    this.watchForAttachments();

    // Setup context menu or button injection
    this.setupUI();
  }

  decodeValue(value) {
    if (value == null) return value;
    try {
      return decodeURIComponent(value);
    } catch (error) {
      return value;
    }
  }

  async loadConfig() {
    return new Promise((resolve) => {
      chrome.storage.sync.get(['apiBase', 'companyId', 'userId'], (result) => {
        this.apiBase = this.decodeValue(result.apiBase) || 'https://flask-6421997997235322.kloudbeansite.com';
        this.companyId = this.decodeValue(result.companyId) || null;
        this.userId = this.decodeValue(result.userId) || null;

        console.log('🔍 ProValuate: Checking credentials in storage...', {
          hasCompanyId: !!this.companyId,
          hasUserId: !!this.userId
        });

        // If credentials are missing, try to sync from cookies
        if (!this.companyId || !this.userId) {
          console.warn('⚠️ ProValuate: Credentials not found in storage. Requesting sync from background script...');
          chrome.runtime.sendMessage({ action: 'syncCookies' }, (response) => {
            if (chrome.runtime.lastError) {
              console.error('❌ Error sending sync message:', chrome.runtime.lastError);
            }

            // Retry getting config after sync with multiple attempts
            let attempts = 0;
            const maxAttempts = 5;
            const retryInterval = setInterval(() => {
              attempts++;
              chrome.storage.sync.get(['apiBase', 'companyId', 'userId'], (retryResult) => {
                this.apiBase = this.decodeValue(retryResult.apiBase) || 'https://flask-6421997997235322.kloudbeansite.com';
                this.companyId = this.decodeValue(retryResult.companyId) || null;
                this.userId = this.decodeValue(retryResult.userId) || null;

                if (this.companyId && this.userId) {
                  console.log('✅ ProValuate: Credentials loaded successfully after', attempts, 'attempt(s)');
                  clearInterval(retryInterval);
                  resolve();
                } else if (attempts >= maxAttempts) {
                  console.error('❌ ProValuate: Credentials still not available after', maxAttempts, 'attempts.');
                  console.error('   Please ensure you are logged in to the ProValuate website at https://devprovaluate.aitamate.com');
                  clearInterval(retryInterval);
                  resolve();
                }
              });
            }, 1000); // Check every 1 second
          });
        } else {
          console.log('✅ ProValuate: Credentials loaded from storage');
          resolve();
        }
      });
    });
  }

  watchForAttachments() {
    const observer = new MutationObserver(() => {
      this.scanForAttachments();
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ["aria-label", "data-filename", "data-testid"]
    });

    // Initial scan
    setTimeout(() => this.scanForAttachments(), 1000);
  }

  scanForAttachments() {
    // ✅ ADD: Prevent multiple simultaneous scans
    if (this._isScanning) {
      console.log('Scan already in progress, skipping duplicate scan');
      return;
    }
    
    this._isScanning = true;
    
    try {
      let collected = [];

      if (this.isGmail) {
        collected = this.scanGmailAttachments();
      } else if (this.isOutlook) {
        collected = this.scanOutlookAttachments();
      }

      // ✅ FIX: Don't merge on normal scans - replace completely for consistency
      this.updateDetectedResumes(collected || [], { mergeExisting: false });
    } finally {
      this._isScanning = false;
    }
  }

  scanGmailAttachments() {
    const discoveredResumes = [];
    const processedLinks = new Set();
    const existingKeys = new Set();
    (this.detectedResumes || []).forEach(resume => {
      const key = this.createResumeKey(resume);
      if (key) existingKeys.add(key);
    });

    const context = this.getGmailAttachmentContext();
    if (!context) {
      console.log('ProValuate: Gmail context not found; skipping scan.');
      return discoveredResumes;
    }

    const { searchScopes, allowedMessageIds } = context;
    const scopedQueryAll = (selector) => {
      const results = [];
      searchScopes.forEach(scope => {
        if (!scope || typeof scope.querySelectorAll !== 'function') return;
        results.push(...Array.from(scope.querySelectorAll(selector)));
      });
      return results;
    };

    const registerResume = (resumeCandidate, linkId, logContext) => {
      const normalized = this.normalizeResumeCandidate(resumeCandidate, this.detectedResumes.length + discoveredResumes.length);
      if (!normalized) return;

      // Only filter by message ID if we have a specific set of allowed message IDs
      // If allowedMessageIds is null or empty, we allow resumes from any message in the thread
      if (allowedMessageIds && allowedMessageIds.size > 0) {
        const messageId = normalized.messageId || this.extractMessageId(normalized.element || normalized.downloadLink);
        if (!messageId || !allowedMessageIds.has(messageId)) {
          return; // Skip this resume if it's not from an allowed message
        }
      }
      // If allowedMessageIds is null or empty, we don't filter - allow all resumes from the thread

      const key = this.createResumeKey(normalized);
      if (!key || existingKeys.has(key)) {
        return;
      }

      existingKeys.add(key);
      if (linkId) processedLinks.add(linkId);
      discoveredResumes.push(normalized);

      if (logContext) {
        console.log(`ProValuate: Found resume ${logContext}:`, normalized.fileName);
      }
    };

    // Strategy 1: Look for ALL links that might be attachments (Gmail-specific)
    const allLinks = scopedQueryAll('a[href]');
    const downloadLinks = Array.from(allLinks).filter(link => {
      const href = link.href?.toLowerCase() || '';
      const text = (link.textContent || '').toLowerCase();
      return href.includes('attid=') ||
        href.includes('attachment') ||
        text.includes('preview attachment') ||
        text.includes('.pdf') ||
        text.includes('.doc') ||
        text.includes('.docx') ||
        text.includes('.txt');
    });
    console.log('ProValuate: Found', downloadLinks.length, 'potential download links out of', allLinks.length, 'total links');

    downloadLinks.forEach(link => {
      const linkId = link.href;
      if (linkId && processedLinks.has(linkId)) return;

      // Try multiple sources for filename, in order of preference
      let fileName = link.getAttribute('download') ||
        link.getAttribute('aria-label') ||
        link.getAttribute('title') ||
        link.textContent.trim() ||
        '';

      // If still no filename, check parent elements more thoroughly
      if (!fileName || fileName.length < 3) {
        const container = link.closest('div[role="listitem"], div[data-attachment-id], div[aria-label*="attachment"], div[data-tooltip*="attachment"], div[class*="attachment"]') ||
          link.parentElement ||
          link.closest('div');

        if (container) {
          // Try container's aria-label or data-tooltip first (most accurate)
          fileName = container.getAttribute('aria-label') ||
            container.getAttribute('data-tooltip') ||
            container.getAttribute('title') ||
            fileName;

          // If still not found, extract from text content
          if (!fileName || fileName.length < 3) {
            const containerText = container.textContent || '';
            const filenameMatch = containerText.match(/([^\s\/\?]+\.(pdf|doc|docx|txt))/i);
            if (filenameMatch) {
              fileName = filenameMatch[1];
            } else {
              // Try to find filename in parent text
              const parent = link.closest('div, span');
              if (parent) {
                const parentText = parent.textContent || '';
                const parentMatch = parentText.match(/([^\s\/\?]+\.(pdf|doc|docx|txt))/i);
                if (parentMatch) {
                  fileName = parentMatch[1];
                } else {
                  fileName = parentText.trim();
                }
              }
            }
          }
        }
      }

      // Clean filename but preserve more of the original structure
      fileName = this.cleanFileName(fileName);

      if (fileName && this.isResume(fileName)) {
        const container = link.closest('div[role="listitem"], div[data-attachment-id], div[aria-label*="attachment"], div[data-tooltip*="attachment"], div[class*="attachment"]') ||
          link.parentElement ||
          link.closest('div');

        registerResume({
          element: container,
          fileName,
          platform: 'gmail',
          downloadLink: link,
          downloadUrl: this.extractDownloadUrlAttribute(container || link)
        }, linkId, 'in Strategy 1');
      }
    });

    // Strategy 2: Look for attachment containers with data attributes (comprehensive)
    const attachmentContainers = scopedQueryAll(
      'div[data-tooltip*="Download"], ' +
      'div[data-tooltip*="download"], ' +
      'div[aria-label*="Attachment"], ' +
      'div[aria-label*="attachment"], ' +
      'div[data-attachment-id], ' +
      'div[role="listitem"], ' +
      'span[data-tooltip*="Download"], ' +
      'span[data-tooltip*="download"]'
    );

    console.log('ProValuate: Found', attachmentContainers.length, 'attachment containers');

    attachmentContainers.forEach(attachment => {
      const link = attachment.querySelector('a[href]');
      if (link && processedLinks.has(link.href)) return;

      // Try multiple sources for filename from attachment container
      let fileName = attachment.getAttribute('aria-label') ||
        attachment.getAttribute('data-tooltip') ||
        attachment.getAttribute('title') ||
        attachment.getAttribute('data-filename') ||
        attachment.textContent.trim();

      if (!fileName || fileName.length < 3) {
        const downloadLink = attachment.querySelector('a[download], a[href*="attachment"], a[href*="download"]');
        if (downloadLink) {
          fileName = downloadLink.getAttribute('download') ||
            downloadLink.getAttribute('aria-label') ||
            downloadLink.getAttribute('title') ||
            downloadLink.textContent.trim() ||
            downloadLink.href.split('/').pop().split('?')[0];
        }
      }

      // Clean filename but preserve more of the original structure
      fileName = this.cleanFileName(fileName);

      if (fileName && this.isResume(fileName)) {
        const downloadLink = attachment.querySelector('a[download], a[href*="attachment"], a[href*="download"]');
        const linkHref = downloadLink?.href;
        registerResume({
          element: attachment,
          fileName,
          platform: 'gmail',
          downloadLink,
          downloadUrl: this.extractDownloadUrlAttribute(attachment)
        }, linkHref, 'in Strategy 2');
      }
    });

    // Strategy 3: Look for file icons with PDF/DOC/DOCX/TXT indicators (all formats)
    const fileIcons = scopedQueryAll(
      'img[alt*="pdf"], img[alt*="doc"], img[alt*="txt"], ' +
      'img[src*="pdf"], img[src*="doc"], img[src*="txt"], ' +
      'img[title*="pdf"], img[title*="doc"], img[title*="txt"]'
    );
    console.log('ProValuate: Found', fileIcons.length, 'file icons');

    fileIcons.forEach(icon => {
      const container = icon.closest('div[role="listitem"], div[data-attachment-id], div[aria-label*="attachment"], div[class*="attachment"]') || icon.parentElement;
      if (!container) return;

      let link = container.querySelector('a[href]');
      if (!link) {
        link = container.parentElement?.querySelector('a[href]') ||
          container.nextElementSibling?.querySelector('a[href]');
      }

      if (link && processedLinks.has(link.href)) return;

      let fileName = link?.getAttribute('download') ||
        link?.getAttribute('aria-label') ||
        link?.textContent?.trim() ||
        '';

      if (!fileName || fileName.length < 3) {
        const containerText = container.textContent || '';
        const filenameMatch = containerText.match(/([^\s\/\?]+\.(pdf|doc|docx|txt))/i);
        fileName = filenameMatch ? filenameMatch[1] : containerText.trim();
      }

      fileName = this.cleanFileName(fileName);

      if (fileName && this.isResume(fileName)) {
        registerResume({
          element: container,
          fileName,
          platform: 'gmail',
          downloadLink: link,
          downloadUrl: this.extractDownloadUrlAttribute(container || link)
        }, link?.href, 'in Strategy 3');
      }
    });

    // Strategy 4: Look for "Preview attachment" text (Gmail-specific pattern)
    const previewElements = scopedQueryAll('span, div, a');
    let strategy4Count = 0;
    previewElements.forEach(element => {
      if (strategy4Count > 20) return;
      const text = element.textContent || '';
      if (!text || (!text.includes('Preview attachment') && !text.includes('preview attachment'))) return;

      const match = text.match(/Preview\s+attachment\s+([^\s]+\.(pdf|doc|docx|txt))/i);
      const fallbackMatch = text.match(/(\d+_)?([A-Za-z0-9_\-]+\.(pdf|doc|docx|txt))/i);
      const candidateName = match?.[1] || fallbackMatch?.[2] || fallbackMatch?.[0];
      const fileName = this.cleanFileName(candidateName || '');

      if (!fileName || !this.isResume(fileName)) return;

      let link = element.closest('a[href*="attid"]') || element.querySelector('a[href*="attid"]') || element.closest('a[href]');
      if (!link) {
        const parent = element.parentElement;
        if (parent) {
          link = parent.querySelector('a[href*="attid"]') || parent.querySelector('a[href]');
        }
      }
      if (!link) {
        const nextSibling = element.nextElementSibling;
        if (nextSibling) {
          link = nextSibling.querySelector('a[href*="attid"]') || nextSibling.querySelector('a[href]');
        }
      }

      const linkHref = link?.href;
      if (linkHref && processedLinks.has(linkHref)) return;

      const wasAdded = (() => {
        const beforeCount = discoveredResumes.length;
        registerResume({
          element: element.closest('div') || element.parentElement || element,
          fileName,
          platform: 'gmail',
          downloadLink: link,
          downloadUrl: this.extractDownloadUrlAttribute(element.closest('div') || link)
        }, linkHref, match ? 'in Strategy 4' : 'in Strategy 4 (fallback)');
        return discoveredResumes.length > beforeCount;
      })();

      if (wasAdded) {
        strategy4Count++;
      }
    });

    return discoveredResumes;
  }

  scanOutlookAttachments() {
    console.log('🔍 ProValuate: Scanning Outlook attachments...');
    const discoveredResumes = [];
    const processedLinks = new Set();

    // Get the current email context to scope the search
    const context = this.getOutlookEmailContext();
    const searchScopes = context.searchScopes || [document];

    console.log(`🔍 Scoping search to ${searchScopes.length} container(s)`);

    // Helper function to query within scoped containers
    const scopedQueryAll = (selector) => {
      const results = [];
      searchScopes.forEach(scope => {
        results.push(...scope.querySelectorAll(selector));
      });
      return results;
    };

    // Method 1: Try data-testid selectors (newer Outlook) - SCOPED
    let attachmentContainer = scopedQueryAll('[data-testid="attachmentContainer"]')[0];
    if (attachmentContainer) {
      console.log('✅ Found attachmentContainer via data-testid');
      const attachments = attachmentContainer.querySelectorAll('[data-testid="attachment-item"]');
      console.log(`Found ${attachments.length} attachments via data-testid`);

      attachments.forEach((attachment, index) => {
        let fileName = attachment.textContent ||
          attachment.getAttribute('aria-label') ||
          attachment.querySelector('span')?.textContent ||
          '';

        fileName = this.cleanFileName(fileName);

        if (fileName && this.isResume(fileName)) {
          const downloadLink = attachment.querySelector('a[download], a[href*="attachment"], a[href*="download"]');
          const normalized = this.normalizeResumeCandidate({
            element: attachment,
            fileName,
            platform: 'outlook',
            downloadLink: downloadLink
          }, index);

          if (normalized) {
            discoveredResumes.push(normalized);
            console.log(`✅ Found resume via data-testid: ${fileName}`);
          }
        }
      });
    }

    // Method 2: Try class-based selectors (older Outlook)
    if (discoveredResumes.length === 0) {
      console.log('🔍 Trying class-based selectors...');
      const classSelectors = [
        '[class*="attachment"]',
        '[class*="Attachment"]',
        '[role="listitem"]',
        '[aria-label*="attachment" i]',
        '[aria-label*="Attachment" i]'
      ];

      classSelectors.forEach(selector => {
        const elements = scopedQueryAll(selector); // SCOPED SEARCH
        console.log(`Found ${elements.length} elements with selector: ${selector}`);

        // Debug logging for aria-label elements
        if (elements.length > 0 && selector.includes('aria-label')) {
          console.log('🔍 DEBUG: Inspecting elements with aria-label="attachment":');
          elements.forEach((el, i) => {
            console.log(`  Element ${i + 1}:`, {
              ariaLabel: el.getAttribute('aria-label'),
              textContent: el.textContent?.substring(0, 100),
              className: el.className?.substring(0, 50),
              links: el.querySelectorAll('a[href]').length,
              buttons: el.querySelectorAll('button').length
            });
          });
        }

        elements.forEach((element, index) => {
          // First, try to extract filename from the element itself
          let fileName = element.getAttribute('aria-label') ||
            element.textContent?.trim() ||
            element.getAttribute('title') ||
            '';

          // Clean and check if it's a resume
          fileName = this.cleanFileName(fileName);
          if (fileName && this.isResume(fileName)) {
            // Find download link
            const downloadLink = element.querySelector('a[href]') ||
              element.closest('a[href]') ||
              element.querySelector('button[onclick*="download"]') ||
              element.querySelector('button[aria-label*="download" i]');

            const normalized = this.normalizeResumeCandidate({
              element: element,
              fileName,
              platform: 'outlook',
              downloadLink: downloadLink
            }, discoveredResumes.length);

            if (normalized) {
              discoveredResumes.push(normalized);
              console.log(`✅ Found resume from element itself: ${fileName}`);
              return; // Skip link search for this element
            }
          }

          // If element itself didn't work, look for file links within the element
          const links = element.querySelectorAll('a[href]');
          if (links.length > 0) {
            console.log(`  Element ${index} has ${links.length} links`);
          }

          links.forEach(link => {
            if (processedLinks.has(link.href)) return;

            const href = link.href.toLowerCase();
            const text = (link.textContent || '').toLowerCase();
            const ariaLabel = (link.getAttribute('aria-label') || '').toLowerCase();

            // Check if this looks like a file attachment
            if (href.includes('attachment') ||
              href.includes('download') ||
              /\.(pdf|doc|docx|txt)(\?|$)/i.test(href) ||
              text.includes('.pdf') ||
              text.includes('.doc') ||
              text.includes('.docx') ||
              text.includes('.txt') ||
              ariaLabel.includes('.pdf') ||
              ariaLabel.includes('.doc') ||
              ariaLabel.includes('.docx') ||
              ariaLabel.includes('.txt')) {

              let fileName = link.textContent?.trim() ||
                link.getAttribute('aria-label') ||
                link.getAttribute('title') ||
                element.textContent?.trim() || // Fallback to parent element
                element.getAttribute('aria-label') || // Fallback to parent aria-label
                link.href.split('/').pop().split('?')[0] ||
                '';

              fileName = this.cleanFileName(fileName);

              if (fileName && this.isResume(fileName)) {
                processedLinks.add(link.href);
                const normalized = this.normalizeResumeCandidate({
                  element: element,
                  fileName,
                  platform: 'outlook',
                  downloadLink: link
                }, discoveredResumes.length);

                if (normalized) {
                  discoveredResumes.push(normalized);
                  console.log(`✅ Found resume via link in element: ${fileName}`);
                }
              }
            }
          });
        });
      });
    }

    // Method 3: Search all links for file attachments (fallback) - SCOPED
    if (discoveredResumes.length === 0) {
      console.log('🔍 Trying link-based search (fallback)...');
      const allLinks = scopedQueryAll('a[href]'); // SCOPED SEARCH
      console.log(`Checking ${allLinks.length} links...`);

      allLinks.forEach(link => {
        if (processedLinks.has(link.href)) return;

        const href = link.href.toLowerCase();
        const text = (link.textContent || '').toLowerCase();
        const ariaLabel = (link.getAttribute('aria-label') || '').toLowerCase();
        const title = (link.getAttribute('title') || '').toLowerCase();

        // Check for resume file patterns - more comprehensive
        const isFileLink = href.includes('attachment') ||
          href.includes('download') ||
          href.includes('getattachment') ||
          /\.(pdf|doc|docx|txt)(\?|$|&)/i.test(href) ||
          /\.(pdf|doc|docx|txt)(\?|$|&)/i.test(text) ||
          /\.(pdf|doc|docx|txt)(\?|$|&)/i.test(ariaLabel) ||
          /\.(pdf|doc|docx|txt)(\?|$|&)/i.test(title);

        if (isFileLink) {
          // Try multiple sources for filename
          let fileName = link.textContent?.trim() ||
            link.getAttribute('aria-label') ||
            link.getAttribute('title') ||
            link.getAttribute('download') ||
            '';

          // If no filename from link, check parent element
          if (!fileName || fileName.length < 3) {
            const parent = link.closest('div, span, li');
            if (parent) {
              fileName = parent.getAttribute('aria-label') ||
                parent.textContent?.trim() ||
                fileName;
            }
          }

          // Last resort: extract from URL
          if (!fileName || fileName.length < 3) {
            const urlParts = link.href.split('/');
            const lastPart = urlParts[urlParts.length - 1].split('?')[0].split('&')[0];
            if (/\.(pdf|doc|docx|txt)$/i.test(lastPart)) {
              fileName = lastPart;
            }
          }

          fileName = this.cleanFileName(fileName);

          if (fileName && this.isResume(fileName)) {
            processedLinks.add(link.href);
            const normalized = this.normalizeResumeCandidate({
              element: link.closest('div') || link.parentElement || link,
              fileName,
              platform: 'outlook',
              downloadLink: link
            }, discoveredResumes.length);

            if (normalized) {
              discoveredResumes.push(normalized);
              console.log(`✅ Found resume via link search: ${fileName}`);
            }
          }
        }
      });
    }

    console.log(`📊 ProValuate: Outlook scan complete. Found ${discoveredResumes.length} resumes`);
    return discoveredResumes;
  }

  isResume(filename) {
    if (!filename) return false;

    // Clean filename first to get accurate extension
    const cleaned = this.cleanFileName(filename);
    const lowerFilename = cleaned.toLowerCase();

    // Check for valid resume extensions (must match Python backend: txt, pdf, doc, docx)
    const resumeExtensions = ['.pdf', '.doc', '.docx', '.txt'];
    const hasValidExtension = resumeExtensions.some(ext => lowerFilename.endsWith(ext));

    // Also check original filename in case cleaning removed extension
    const originalLower = filename.toLowerCase();
    const hasOriginalExtension = resumeExtensions.some(ext => originalLower.includes(ext));

    return hasValidExtension || hasOriginalExtension;
  }

  cleanFileName(fileName) {
    if (!fileName) return '';

    // ✅ IMPROVE: Store original for deterministic fallback
    const originalFileName = fileName;

    // Remove "Preview attachment" prefix (case insensitive, anywhere in string)
    fileName = fileName.replace(/Preview\s+attachment\s+/gi, '');

    // Remove file size suffixes like "126 KB", "2.5 MB" (anywhere in string)
    fileName = fileName.replace(/\s+\d+[.,]?\d*\s*(KB|MB|GB|bytes?)/gi, '');

    // Extract filename from URL if present
    if (fileName.includes('/')) {
      fileName = fileName.split('/').pop();
    }

    // Remove query parameters
    if (fileName.includes('?')) {
      fileName = fileName.split('?')[0];
    }

    // ✅ IMPROVE: More deterministic pattern matching - prioritize most specific pattern first
    // Try to find the cleanest filename pattern in order of preference
    let cleaned = null;
    
    // Pattern 1: Clean filename with optional timestamp prefix (most specific - try this first)
    // Match: "1753968507708_Sachin_Adate_Golang_Developer.pdf" -> "Sachin_Adate_Golang_Developer.pdf"
    const cleanPattern = /(?:(\d{10,})_)?([A-Za-z][A-Za-z0-9_\-\s]{2,}\.(pdf|doc|docx|txt))/i;
    const cleanMatch = fileName.match(cleanPattern);
    if (cleanMatch && cleanMatch[2]) {
      cleaned = cleanMatch[2].trim();
    }
    
    // Pattern 2: Any filename with extension starting with letter (fallback)
    if (!cleaned) {
      const extPattern = /([A-Za-z][A-Za-z0-9_\-\s]{2,}\.(pdf|doc|docx|txt))/i;
      const extMatch = fileName.match(extPattern);
      if (extMatch && extMatch[1]) {
        cleaned = extMatch[1].trim();
      }
    }
    
    // Pattern 3: Last resort - any .ext pattern
    if (!cleaned) {
      const anyExtPattern = /([^\/\?\s]+\.(pdf|doc|docx|txt))/i;
      const anyExtMatch = fileName.match(anyExtPattern);
      if (anyExtMatch && anyExtMatch[1]) {
        cleaned = anyExtMatch[1].trim();
      }
    }
    
    // If we found a cleaned version, use it; otherwise use original (minus prefixes/suffixes)
    if (cleaned) {
      fileName = cleaned.replace(/\s+/g, '_'); // Normalize spaces to underscores
    } else {
      // Fallback: use original but clean it up
      fileName = originalFileName.split(/[\/\?]/).pop().split('?')[0].trim();
    }

    // Remove timestamp prefixes (numbers at start followed by underscore)
    // Pattern: 1753968507708_filename.pdf -> filename.pdf
    fileName = fileName.replace(/^\d{10,}_/, '');

    // Remove any timestamps in the middle (long numbers like 1753968507708)
    // Pattern: "Sachin_Adate_Golang_Developer1753968507708_Sachin.pdf" -> "Sachin_Adate_Golang_Developer.pdf"
    fileName = fileName.replace(/\d{10,}_/g, ''); // Remove timestamps (10+ digits followed by underscore)
    fileName = fileName.replace(/_\d{10,}/g, ''); // Remove timestamps (underscore followed by 10+ digits)
    fileName = fileName.replace(/\d{10,}(?=[A-Za-z])/g, ''); // Remove timestamps before letters (no underscore)

    // Remove duplicate filename parts (if same name appears multiple times)
    const extMatch = fileName.match(/\.(pdf|doc|docx|txt)$/i);
    if (extMatch) {
      const ext = extMatch[0];
      let nameWithoutExt = fileName.replace(ext, '');

      // Split by common separators and filter out timestamps and empty parts
      const nameParts = nameWithoutExt.split(/[_\s-]+/).filter(p => {
        return p && p.length > 0 && !/^\d{10,}$/.test(p); // Remove timestamps (10+ digits)
      });

      // Remove duplicates (if same part appears multiple times consecutively)
      const uniqueParts = [];
      const seenParts = new Set();
      nameParts.forEach(part => {
        const lowerPart = part.toLowerCase();
        // Only add if we haven't seen this part before (case-insensitive) and it's not a timestamp
        if (!seenParts.has(lowerPart) && part.length > 1) {
          uniqueParts.push(part);
          seenParts.add(lowerPart);
        }
      });

      // If we have too many parts, it might be duplicated - take first reasonable chunk
      if (uniqueParts.length > 8) {
        fileName = uniqueParts.slice(0, 6).join('_') + ext;
      } else if (uniqueParts.length > 0) {
        fileName = uniqueParts.join('_') + ext;
      } else {
        // Fallback: use original if no valid parts found
        fileName = nameWithoutExt.replace(/\d{10,}/g, '').replace(/_{2,}/g, '_') + ext;
      }
    }

    // Final cleanup: Remove any remaining "Preview attachment" text
    fileName = fileName.replace(/Preview\s+attachment\s+/gi, '');

    // Trim whitespace
    fileName = fileName.trim();

    return fileName;
  }

  addEvaluateButton(attachmentElement, platform, resumeInfo) {
    // REMOVED: No longer adding buttons to attachments
    // Only the floating button will be used to avoid confusion
    // This function is kept for compatibility but does nothing
    return;
  }

  setupUI() {
    // Add a floating button to open the assessment modal
    if (!document.querySelector('#provaluate-floating-btn')) {
      const floatingBtn = document.createElement('div');
      floatingBtn.id = 'provaluate-floating-btn';
      floatingBtn.className = 'provaluate-floating-btn';
      
      // ✅ FIX: Use favicon.png as the button image - transparent background, slightly larger size
      const faviconUrl = chrome.runtime.getURL('favicon.png');
      floatingBtn.innerHTML = `<img src="${faviconUrl}" alt="ProValuate" style="width: 48px; height: 48px; display: block;" />`;
      floatingBtn.title = 'Open ProValuate Resume Assessment';
      floatingBtn.style.padding = '0';
      floatingBtn.style.borderRadius = '0';
      floatingBtn.style.background = 'transparent';
      floatingBtn.style.border = 'none';
      floatingBtn.style.width = '48px';
      floatingBtn.style.height = '48px';
      floatingBtn.style.minWidth = '48px';
      floatingBtn.style.minHeight = '48px';
      floatingBtn.style.boxShadow = 'none';
      // Override hover state to keep transparent
      floatingBtn.addEventListener('mouseenter', () => {
        floatingBtn.style.background = 'transparent';
        floatingBtn.style.transform = 'scale(1.1)'; // Slight zoom on hover
      });
      floatingBtn.addEventListener('mouseleave', () => {
        floatingBtn.style.background = 'transparent';
        floatingBtn.style.transform = 'scale(1)';
      });

      floatingBtn.addEventListener('click', () => {
        this.showAssessmentModal();
      });

      document.body.appendChild(floatingBtn);
    }
  }

  async handleEvaluateClick() {
    // Rescan to get latest resumes
    this.scanForAttachments();

    // Wait a bit for scan to complete
    await new Promise(resolve => setTimeout(resolve, 500));

    if (this.detectedResumes.length === 0) {
      // Try one more aggressive scan
      this.aggressiveScan();
      await new Promise(resolve => setTimeout(resolve, 500));

      if (this.detectedResumes.length === 0) {
        this.showNotification('No resume attachments detected. Please ensure the email is fully loaded and contains PDF/DOC/DOCX/TXT files.', 'warning');
        console.log('ProValuate: No resumes found. Open browser console (F12) for debugging info.');
        return;
      }
    }

    this.showAssessmentModal();
  }

  aggressiveScan() {
    // ✅ ADD: Respect scanning lock
    if (this._isScanning) {
      console.log('Scan already in progress, skipping aggressive scan');
      return;
    }
    
    this._isScanning = true;
    
    try {
      console.log('ProValuate: Running aggressive scan...');

      // For Outlook, use the improved scanOutlookAttachments
      if (this.isOutlook) {
        console.log('🔍 Running aggressive Outlook scan...');
        const outlookResumes = this.scanOutlookAttachments();
        if (outlookResumes.length > 0) {
          // ✅ FIX: Merge with existing for aggressive scan (it's meant to find more)
          this.updateDetectedResumes(outlookResumes, { mergeExisting: true });
          console.log(`✅ Aggressive Outlook scan found ${outlookResumes.length} resumes`);
        }
        return;
      }

      // Original Gmail aggressive scan logic
    const context = this.isGmail ? this.getGmailAttachmentContext() : null;
    const searchScopes = context ? context.searchScopes : [document];
    const allowedMessageIds = context?.allowedMessageIds || null;

    const scopedQueryAll = (selector) => {
      const results = [];
      searchScopes.forEach(scope => {
        if (!scope || typeof scope.querySelectorAll !== 'function') return;
        results.push(...Array.from(scope.querySelectorAll(selector)));
      });
      return results;
    };

    const collected = [];
    const processedLinks = new Set();

    const candidateLinks = scopedQueryAll('a[href]');
    console.log('ProValuate: Checking', candidateLinks.length, 'links in aggressive scan');

    candidateLinks.forEach(link => {
      const href = link.href?.toLowerCase() || '';
      const text = (link.textContent || '').toLowerCase();

      if (
        href.includes('attachment') ||
        href.includes('attid') ||
        href.includes('mail-attachment') ||
        text.includes('.pdf') ||
        text.includes('.doc') ||
        text.includes('.docx') ||
        text.includes('.txt')
      ) {
        let fileName = link.getAttribute('download') ||
          link.getAttribute('aria-label') ||
          link.textContent.trim() ||
          '';

        if (!fileName || fileName.length < 3) {
          const parent = link.closest('div, span');
          if (parent) {
            const parentText = parent.textContent || '';
            const previewMatch = parentText.match(/Preview\s+attachment\s+([^\s]+\.(pdf|doc|docx|txt))/i);
            if (previewMatch) {
              fileName = previewMatch[1];
            } else {
              const filenameMatch = parentText.match(/([^\s\/\?]+\.(pdf|doc|docx|txt))/i);
              if (filenameMatch) {
                fileName = filenameMatch[1];
              } else {
                fileName = parentText.trim();
              }
            }
          }
        }

        fileName = this.cleanFileName(fileName);

        if (fileName && this.isResume(fileName)) {
          const container = link.closest('div') || link.parentElement;
          const messageElement = container || link;
          const messageId = allowedMessageIds && allowedMessageIds.size > 0
            ? this.extractMessageId(messageElement)
            : null;

          if (allowedMessageIds && allowedMessageIds.size > 0 && (!messageId || !allowedMessageIds.has(messageId))) {
            return;
          }

          if (processedLinks.has(link.href)) return;
          processedLinks.add(link.href);

          collected.push({
            element: container,
            fileName,
            platform: this.isGmail ? 'gmail' : 'outlook',
            downloadLink: link,
            messageId: messageId || undefined
          });
          console.log('ProValuate: Found resume via aggressive scan:', fileName);
        }
      }
    });

      if (collected.length > 0) {
        this.updateDetectedResumes(collected, { mergeExisting: true });
      }

      console.log('ProValuate: Aggressive scan complete. Total resumes:', this.detectedResumes.length);
    } finally {
      this._isScanning = false;
    }
  }

  async showAssessmentModal() {
    // ✅ ADD: Prevent opening multiple modals
    if (this._isModalOpen) {
      console.log('Modal already open, focusing existing modal');
      const existingModal = document.querySelector('#provaluate-modal');
      if (existingModal) {
        existingModal.style.display = 'flex';
        existingModal.focus();
      }
      return;
    }

    // ✅ ADD: Debounce button clicks
    const now = Date.now();
    if (now - this._lastButtonClickTime < 500) {
      console.log('Button click debounced');
      return;
    }
    this._lastButtonClickTime = now;

    // ✅ FIX: Clear previous scan results and do a fresh scan for consistency
    this.detectedResumes = [];
    this.scanForAttachments();

    // Wait a moment for scan to complete
    await new Promise(resolve => setTimeout(resolve, 600));

    // If still no resumes, try aggressive scan
    if (this.detectedResumes.length === 0) {
      console.log('ProValuate: Initial scan found 0 resumes, running aggressive scan...');
      this.aggressiveScan();
      await new Promise(resolve => setTimeout(resolve, 500));
      console.log('ProValuate: After aggressive scan, found', this.detectedResumes.length, 'resumes');
    }

    // Check if config is loaded
    if (!this.companyId || !this.userId) {
      this.showNotification('Please log in to the ProValuate website first to use the extension', 'error');
      console.error('ProValuate: Missing credentials. User must log in to website first.');
      return;
    }

    // Show modal even if no resumes detected - user can manually scan
    if (this.detectedResumes.length === 0) {
      console.log('ProValuate: Still 0 resumes after all scans. Showing modal with scan option.');
      this.showNotification('No resumes detected. Click "Scan Again" to retry.', 'warning');
    } else {
      console.log('ProValuate: Found', this.detectedResumes.length, 'resumes:', this.detectedResumes.map(r => r.fileName));
    }

    // Load job descriptions and criteria
    const [jobDescriptions, criteria] = await Promise.all([
      this.fetchJobDescriptions(),
      this.fetchCriteria()
    ]);

    // ✅ ADD: Set modal open flag
    this._isModalOpen = true;

    // Create modal
    const modal = document.createElement('div');
    modal.className = 'provaluate-modal-overlay';
    modal.id = 'provaluate-modal';

    modal.innerHTML = `
      <div class="provaluate-modal">
        <div class="provaluate-modal-header">
          <h2>ProValuate Resume Assessment</h2>
          <button class="provaluate-close-btn">&times;</button>
        </div>
        
        <div class="provaluate-modal-content">
          <div class="provaluate-section">
            <label class="provaluate-label">
              <strong>Job Description *</strong>
              <div style="display: flex; align-items: center; gap: 8px;">
                <select id="provaluate-jd-select" class="provaluate-select" required style="flex: 1;">
                  <option value="">Select a Job Description...</option>
                  ${jobDescriptions.map(jd =>
      `<option value="${jd.jd_id}">${jd.title || 'Untitled JD'}</option>`
    ).join('')}
                </select>
                <a href="${this.getWebsiteUrl()}/dashboard?section=job-upload" target="_blank" style="color: #2C77CA; text-decoration: none; font-size: 12px; white-space: nowrap;" title="Create new Job Description">
                  + New JD
                </a>
              </div>
            </label>
          </div>

          <div class="provaluate-section">
            <label class="provaluate-label">
              <strong>Evaluation Criteria *</strong>
              <div style="display: flex; align-items: center; gap: 8px;">
                <select id="provaluate-criteria-select" class="provaluate-select" required style="flex: 1;">
                  <option value="">Select Criteria...</option>
                  ${criteria.map(c =>
      `<option value="${c.criteria_id}">${c.criteria_name || 'Untitled Criteria'}</option>`
    ).join('')}
                </select>
                <a href="${this.getWebsiteUrl()}/dashboard?section=evaluation-criteria" target="_blank" style="color: #2C77CA; text-decoration: none; font-size: 12px; white-space: nowrap;" title="Create new Evaluation Criteria">
                  + New Criteria
                </a>
              </div>
            </label>
          </div>

          <div class="provaluate-section">
            <label class="provaluate-label">
              <strong>Resumes Detected (${this.detectedResumes.length})</strong>
              ${this.detectedResumes.length > 0 ? `
              <div class="provaluate-resume-list">
                ${this.detectedResumes.map((resume, idx) =>
      `<div class="provaluate-resume-item">
                    <input type="checkbox" 
                           class="provaluate-resume-checkbox" 
                           data-resume-index="${idx}" 
                           checked 
                           id="resume-checkbox-${idx}">
                    <label for="resume-checkbox-${idx}" class="resume-checkbox-label">
                      <span class="resume-icon">📄</span>
                      <span class="resume-name">${resume.fileName}</span>
                    </label>
                  </div>`
    ).join('')}
              </div>
              ` : `
              <div class="provaluate-resume-list" style="text-align: center; padding: 20px; color: #6B7280;">
                <p>No resumes detected. Click "Scan Again" to retry detection.</p>
                <button class="provaluate-btn" id="provaluate-scan-again" style="margin-top: 10px;">Scan Again</button>
              </div>
              `}
            </label>
          </div>

          <div class="provaluate-loading" id="provaluate-loading" style="display:none;">
            <div class="provaluate-spinner"></div>
            <p id="provaluate-loading-text">Preparing assessment...</p>
            <div class="provaluate-progress">
              <div class="provaluate-progress-bar" id="provaluate-progress-bar"></div>
            </div>
            <p class="provaluate-progress-text" id="provaluate-progress-text">0 / ${this.detectedResumes.length} resumes</p>
          </div>
        </div>

        <div class="provaluate-modal-footer">
          <button class="provaluate-btn provaluate-cancel-btn">Cancel</button>
          <button class="provaluate-btn provaluate-assess-btn" id="provaluate-assess-btn" ${this.detectedResumes.length === 0 ? 'disabled' : ''}>Assess Resumes</button>
        </div>
      </div>
    `;

    document.body.appendChild(modal);

    // Event listeners
    modal.querySelector('.provaluate-close-btn').addEventListener('click', () => this.closeModal());
    modal.querySelector('.provaluate-cancel-btn').addEventListener('click', () => this.closeModal());

    // ✅ ADD: JD selection change handler to refetch criteria
    const jdSelect = modal.querySelector('#provaluate-jd-select');
    const criteriaSelect = modal.querySelector('#provaluate-criteria-select');

    jdSelect.addEventListener('change', async (e) => {
      const selectedJdId = e.target.value;
      
      // Clear current criteria selection
      criteriaSelect.innerHTML = '<option value="">Select Criteria...</option>';
      
      if (selectedJdId) {
        // Show loading state
        criteriaSelect.disabled = true;
        const originalHTML = criteriaSelect.innerHTML;
        criteriaSelect.innerHTML = '<option value="">Loading criteria...</option>';
        
        try {
          // Fetch criteria filtered by selected JD
          const filteredCriteria = await this.fetchCriteria(selectedJdId);
          
          // Populate criteria dropdown
          criteriaSelect.innerHTML = '<option value="">Select Criteria...</option>';
          filteredCriteria.forEach(c => {
            const option = document.createElement('option');
            option.value = c.criteria_id;
            option.textContent = c.criteria_name || 'Untitled Criteria';
            criteriaSelect.appendChild(option);
          });
        } catch (error) {
          console.error('Error fetching criteria for JD:', error);
          criteriaSelect.innerHTML = originalHTML;
          this.showNotification('Failed to load criteria for selected JD', 'warning');
        } finally {
          criteriaSelect.disabled = false;
        }
      } else {
        // No JD selected, fetch default criteria only
        try {
          const defaultCriteria = await this.fetchCriteria(null);
          criteriaSelect.innerHTML = '<option value="">Select Criteria...</option>';
          defaultCriteria.forEach(c => {
            const option = document.createElement('option');
            option.value = c.criteria_id;
            option.textContent = c.criteria_name || 'Untitled Criteria';
            criteriaSelect.appendChild(option);
          });
        } catch (error) {
          console.error('Error fetching default criteria:', error);
        }
      }
    });

    // ✅ FIX: Use a flag to prevent multiple simultaneous clicks
    modal.querySelector('#provaluate-assess-btn').addEventListener('click', async () => {
      if (this._isAssessing) {
        console.log('Assessment already in progress, ignoring click');
        return;
      }
      await this.startAssessment(modal);
    });

    // Scan again button
    const scanAgainBtn = modal.querySelector('#provaluate-scan-again');
    if (scanAgainBtn) {
      scanAgainBtn.addEventListener('click', async () => {
        scanAgainBtn.disabled = true;
        scanAgainBtn.textContent = 'Scanning...';
        
        // ✅ FIX: Clear previous results and do fresh scan for consistency
        this.detectedResumes = [];
        this.scanForAttachments();
        await new Promise(resolve => setTimeout(resolve, 600));
        
        // Only run aggressive scan if regular scan found nothing
        if (this.detectedResumes.length === 0) {
          this.aggressiveScan();
          await new Promise(resolve => setTimeout(resolve, 600));
        }

        // Update the resume list
        const resumeList = modal.querySelector('.provaluate-resume-list');
        if (this.detectedResumes.length > 0) {
          resumeList.innerHTML = this.detectedResumes.map((resume, idx) =>
            `<div class="provaluate-resume-item">
              <input type="checkbox" 
                     class="provaluate-resume-checkbox" 
                     data-resume-index="${idx}" 
                     checked 
                     id="resume-checkbox-${idx}">
              <label for="resume-checkbox-${idx}" class="resume-checkbox-label">
                <span class="resume-icon">📄</span>
                <span class="resume-name">${resume.fileName}</span>
              </label>
            </div>`
          ).join('');
          const label = modal.querySelector('.provaluate-label strong');
          if (label) {
            label.textContent = `Resumes Detected (${this.detectedResumes.length})`;
          }
        } else {
          resumeList.innerHTML = '<p style="text-align: center; padding: 20px; color: #6B7280;">No resumes found. Make sure the email is fully loaded.</p>';
        }
        scanAgainBtn.disabled = false;
        scanAgainBtn.textContent = 'Scan Again';
      });
    }
  }

  async fetchJobDescriptions() {
    try {
      const response = await fetch(`${this.apiBase}/api/job_descriptions?company_id=${this.companyId}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        }
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: Failed to fetch job descriptions`);
      }

      const result = await response.json();
      return result.data || [];
    } catch (error) {
      console.error('Error fetching job descriptions:', error);
      this.showNotification('Failed to load job descriptions', 'error');
      return [];
    }
  }

  async fetchCriteria(jdId = null) {
    try {
      let url = `${this.apiBase}/api/criteria?company_id=${this.companyId}`;
      
      // ✅ ADD: Include jd_id in query if provided
      if (jdId) {
        url += `&jd_id=${encodeURIComponent(jdId)}`;
      }
      
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        }
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: Failed to fetch criteria`);
      }

      const result = await response.json();
      return result.data || [];
    } catch (error) {
      console.error('Error fetching criteria:', error);
      // Don't show error for criteria as it's optional
      return [];
    }
  }

  getSelectedResumes() {
    // ✅ FIX: Query within modal scope to avoid finding wrong checkboxes
    const modal = document.querySelector('.provaluate-modal');
    if (!modal) {
      console.warn('Modal not found, falling back to global query');
      const checkboxes = document.querySelectorAll('.provaluate-resume-checkbox:checked');
      const selectedIndices = Array.from(checkboxes).map(cb => parseInt(cb.getAttribute('data-resume-index')));
      return this.detectedResumes.filter((resume, idx) => selectedIndices.includes(idx));
    }

    // Query checkboxes within modal
    const checkboxes = modal.querySelectorAll('.provaluate-resume-checkbox:checked');
    const selectedIndices = Array.from(checkboxes).map(cb => {
      const index = cb.getAttribute('data-resume-index');
      return index !== null ? parseInt(index) : -1;
    }).filter(idx => idx >= 0);

    console.log(`Selected ${selectedIndices.length} resumes (indices: ${selectedIndices.join(', ')})`);
    console.log(`Total detected resumes: ${this.detectedResumes.length}`);

    // ✅ FIX: If no checkboxes found but resumes detected, use all detected resumes
    if (selectedIndices.length === 0 && this.detectedResumes.length > 0) {
      console.warn('No checkboxes selected, but resumes detected. Using all detected resumes.');
      return [...this.detectedResumes];
    }

    return this.detectedResumes.filter((resume, idx) => selectedIndices.includes(idx));
  }

  async startAssessment(modal) {
    // ✅ FIX: Add early return if already assessing
    if (this._isAssessing) {
      console.log('Assessment already in progress');
      return;
    }
    this._isAssessing = true;
    this._modalClosedDuringProcessing = false; // ✅ Reset flag when starting new assessment

    const jdId = document.querySelector('#provaluate-jd-select')?.value;
    const criteriaId = document.querySelector('#provaluate-criteria-select')?.value; // ✅ FIX: Remove || null, make it required

    if (!jdId) {
      this.showNotification('Please select a Job Description', 'warning');
      this._isAssessing = false;
      return;
    }

    // ✅ ADD: Validate criteria is selected (now required)
    if (!criteriaId) {
      this.showNotification('Please select an Evaluation Criteria', 'warning');
      this._isAssessing = false;
      return;
    }

    // ✅ FIX: Re-scan and wait for detection to complete
    console.log('Re-scanning for resumes before assessment...');
    this.scanForAttachments();
    await new Promise(resolve => setTimeout(resolve, 300)); // Wait for scan

    // ✅ FIX: If still no resumes, try aggressive scan
    if (this.detectedResumes.length === 0) {
      console.log('No resumes found, trying aggressive scan...');
      this.aggressiveScan();
      await new Promise(resolve => setTimeout(resolve, 300));
    }

    // Get selected resumes from checkboxes
    const selectedResumes = this.getSelectedResumes();
    console.log(`Selected resumes count: ${selectedResumes.length}, Detected resumes count: ${this.detectedResumes.length}`);

    if (selectedResumes.length === 0) {
      // ✅ FIX: Better error message
      if (this.detectedResumes.length === 0) {
        this.showNotification('No resume attachments detected. Please ensure the email is fully loaded and contains PDF/DOC/DOCX/TXT files.', 'warning');
      } else {
        this.showNotification('Please select at least one resume to assess (check the boxes next to resumes)', 'warning');
      }
      this._isAssessing = false;
      return;
    }

    const context = this.isGmail ? this.getGmailAttachmentContext() : null;
    let resumesToProcess = [...selectedResumes];
    // Only filter by message ID if we have a specific set of allowed message IDs
    // If allowedMessageIds is null, we process all selected resumes from the thread
    if (context && context.allowedMessageIds && context.allowedMessageIds.size > 0) {
      resumesToProcess = resumesToProcess.filter(resume => {
        const messageId = resume.messageId || this.extractMessageId(resume.element || resume.downloadLink);
        return messageId && context.allowedMessageIds.has(messageId);
      });

      if (resumesToProcess.length === 0) {
        this.showNotification('No resumes detected for this email. Please open the email containing attachments.', 'warning');
        this._isAssessing = false;
        return;
      }
    }
    // If allowedMessageIds is null or empty, process all selected resumes (from entire thread)

    // ✅ FIX: Save JD and criteria to sessionStorage for main app sync
    try {
      if (typeof sessionStorage !== 'undefined') {
        sessionStorage.setItem('selectedJDId', jdId);
        if (criteriaId) {
          sessionStorage.setItem('selectedCriteriaGridId', criteriaId);
        }
        console.log('Saved JD and criteria to sessionStorage:', { jdId, criteriaId });
      }
    } catch (e) {
      console.warn('Could not save to sessionStorage:', e);
    }

    // Show loading state
    const loadingDiv = document.querySelector('#provaluate-loading');
    const assessBtn = document.querySelector('#provaluate-assess-btn');
    const progressBar = document.querySelector('#provaluate-progress-bar');
    const progressText = document.querySelector('#provaluate-progress-text');
    const loadingText = document.querySelector('#provaluate-loading-text');

    loadingDiv.style.display = 'flex';
    assessBtn.disabled = true;
    assessBtn.textContent = 'Assessing...';

    try {
      // Step 1: Upload resumes and get URLs
      loadingText.textContent = 'Uploading resumes...';
      const resumeUrls = await this.uploadResumes(resumesToProcess);

      if (resumeUrls.length === 0) {
        throw new Error('Failed to upload resumes');
      }

      // ✅ ADD: Close modal after successful upload and notify user
      this.closeModal();
      this.showNotification(`✅ Successfully uploaded ${resumeUrls.length} resume(s). Analysis is starting in background...`, 'success');

      // Step 2: Analyze resumes (continues in background after modal is closed)
      const analysisData = {
        jd_id: jdId,
        criteria_id: criteriaId,
        resume_urls: resumeUrls,
        company_id: this.companyId
      };

      const totalResumes = resumeUrls.length;

      // Start analysis (no progress bar updates since modal is closed)
      const response = await fetch(`${this.apiBase}/cv/analyze_resumes`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Request-Source': 'chrome-extension'  // ✅ ADD: Custom header to identify extension calls
        },
        body: JSON.stringify(analysisData)
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ error: 'Analysis failed' }));
        throw new Error(errorData.error || `HTTP ${response.status}: Analysis failed`);
      }

      const result = await response.json();

      // ✅ FIX: Modal is already closed, so always show notification and floating button
      this.showAssessmentCompleteNotification(result, totalResumes, jdId, criteriaId);

    } catch (error) {
      console.error('Assessment error:', error);
      // Modal might be closed, so always show notification
      this.showNotification(`Assessment failed: ${error.message}`, 'error');
    } finally {
      // ✅ FIX: Always reset the flag
      this._isAssessing = false;
    }
  }

  async uploadResumes(resumes = this.detectedResumes) {
    const uploadedUrls = [];
    const loadingText = document.querySelector('#provaluate-loading-text');
    const totalResumes = resumes.length;

    for (let i = 0; i < resumes.length; i++) {
      const resume = resumes[i];

      try {
        loadingText.textContent = `Uploading resume ${i + 1} of ${totalResumes}: ${resume.fileName}`;

        // Get download URL from attachment element
        const downloadUrl = await this.getAttachmentDownloadUrl(resume);

        if (!downloadUrl) {
          console.warn(`Could not get download URL for ${resume.fileName}`);
          // Try to use the resume URL directly if available
          continue;
        }

        // Fetch the file from the download URL
        let fileBlob = null;
        try {
          const fileResponse = await fetch(downloadUrl);
          if (fileResponse.ok) {
            fileBlob = await fileResponse.blob();
          } else {
            // If direct fetch fails, try using background script download API
            const file = await this.downloadViaBackgroundScript(resume, downloadUrl);
            if (file) {
              fileBlob = file;
            } else {
              throw new Error('Could not download file');
            }
          }
        } catch (fetchError) {
          // Fallback: Use background script to download
          const file = await this.downloadViaBackgroundScript(resume, downloadUrl);
          if (file) {
            fileBlob = file;
          } else {
            throw fetchError;
          }
        }

        if (!fileBlob) {
          throw new Error(`Failed to download ${resume.fileName}`);
        }

        // Create File object from blob
        const file = new File([fileBlob], resume.fileName, {
          type: fileBlob.type || 'application/pdf'
        });

        // Upload to backend
        const formData = new FormData();
        formData.append('file', file);
        formData.append('jd_id', document.querySelector('#provaluate-jd-select').value);
        formData.append('criteria_id', document.querySelector('#provaluate-criteria-select').value || '');
        formData.append('user_id', this.userId);
        formData.append('company_id', this.companyId);
        formData.append('candidate_name', resume.fileName.split('.')[0]);

        const response = await fetch(`${this.apiBase}/cv/upload`, {
          method: 'POST',
          body: formData
        });

        if (!response.ok) {
          const errorData = await response.json().catch(() => ({}));
          throw new Error(errorData.error || `Upload failed for ${resume.fileName}`);
        }

        const result = await response.json();
        if (result.file_url) {
          uploadedUrls.push(result.file_url);
        } else {
          throw new Error('No file URL returned from upload');
        }

      } catch (error) {
        console.error(`Error uploading ${resume.fileName}:`, error);
        // Continue with other resumes even if one fails
      }
    }

    return uploadedUrls;
  }

  async getAttachmentDownloadUrl(resumeInfo) {
    try {
      const attachmentElement = resumeInfo.element;
      let downloadLink = null;

      if (resumeInfo.platform === 'gmail') {
        // Use stored download link if available
        if (resumeInfo.downloadLink) {
          downloadLink = resumeInfo.downloadLink;
        } else {
          // Gmail: Find download link with multiple strategies
          downloadLink = attachmentElement.querySelector('a[download]') ||
            attachmentElement.querySelector('a[href*="attachment"]') ||
            attachmentElement.querySelector('a[href*="mail-attachment"]') ||
            attachmentElement.querySelector('a[href*="download"]') ||
            attachmentElement.querySelector('a[role="button"]') ||
            attachmentElement.closest('div').querySelector('a[download]');
        }
      } else if (resumeInfo.platform === 'outlook') {
        // Outlook: Find download link
        downloadLink = attachmentElement.querySelector('a[href*="download"]') ||
          attachmentElement.querySelector('a[data-testid*="download"]');
      }

      if (downloadLink && downloadLink.href) {
        return downloadLink.href;
      }

      // Try to get URL from data attributes
      const dataUrl = attachmentElement.getAttribute('data-url') ||
        attachmentElement.getAttribute('data-download-url');

      return dataUrl || null;
    } catch (error) {
      console.error('Error getting download URL:', error);
      return null;
    }
  }

  async downloadViaBackgroundScript(resumeInfo, downloadUrl) {
    return new Promise((resolve) => {
      // Send message to background script to handle download
      chrome.runtime.sendMessage({
        action: 'downloadFile',
        url: downloadUrl,
        filename: resumeInfo.fileName
      }, (response) => {
        if (response && response.success && response.fileBlob) {
          // Convert base64 to blob
          const byteCharacters = atob(response.fileBlob);
          const byteNumbers = new Array(byteCharacters.length);
          for (let i = 0; i < byteCharacters.length; i++) {
            byteNumbers[i] = byteCharacters.charCodeAt(i);
          }
          const byteArray = new Uint8Array(byteNumbers);
          const blob = new Blob([byteArray], { type: 'application/pdf' });
          resolve(blob);
        } else {
          resolve(null);
        }
      });
    });
  }

  getWebsiteUrl() {
    // Construct website URL from apiBase
    // devprovaluate_py.aitamate.com -> devprovaluate.aitamate.com
    // https://devprovaluate_py.aitamate.com -> https://devprovaluate.aitamate.com
    let url = this.apiBase || 'https://flask-6421997997235322.kloudbeansite.com';
    // Convert backend URL to frontend URL
    url = url.replace('flask-6421997997235322.kloudbeansite.com', 'provaluate.aitamate.com');
    url = url.replace('_py', ''); // Remove _py from domain
    url = url.replace('/api', ''); // Remove /api if present
    url = url.replace(/\/$/, ''); // Remove trailing slash
    // Ensure it starts with https://
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      url = 'https://' + url;
    }
    return url;
  }

  showCompletionModal(originalModal, result, totalResumes) {
    const content = originalModal.querySelector('.provaluate-modal-content');
    const websiteUrl = this.getWebsiteUrl();

    // ✅ FIX: Get JD and criteria IDs from the modal (they were saved to sessionStorage earlier)
    const jdId = document.querySelector('#provaluate-jd-select')?.value || sessionStorage.getItem('selectedJDId') || '';
    const criteriaId = document.querySelector('#provaluate-criteria-select')?.value || sessionStorage.getItem('selectedCriteriaGridId') || '';

    content.innerHTML = `
      <div class="provaluate-completion">
        <div class="provaluate-success-icon">✓</div>
        <h2>Assessment Complete!</h2>
        <p class="provaluate-completion-message">
          Successfully assessed <strong>${totalResumes}</strong> resume(s) against the selected job description.
        </p>
        <div class="provaluate-completion-details">
          <p><strong>Status:</strong> Done</p>
          <p><strong>Total Resumes:</strong> ${totalResumes}</p>
          ${result.successful_analyses ? `<p><strong>Successful:</strong> ${result.successful_analyses}</p>` : ''}
          ${result.failed_analyses ? `<p><strong>Failed:</strong> ${result.failed_analyses}</p>` : ''}
        </div>
        <div class="provaluate-completion-note">
          <p>You can now log in to your ProValuate dashboard to view detailed reports and analysis results.</p>
        </div>
      </div>
    `;

    originalModal.querySelector('.provaluate-modal-footer').innerHTML = `
      <button class="provaluate-btn provaluate-primary-btn" id="provaluate-open-dashboard">Open Dashboard</button>
      <button class="provaluate-btn provaluate-cancel-btn">Close</button>
    `;

    // Add proper event listener for Open Dashboard button
    const openDashboardBtn = originalModal.querySelector('#provaluate-open-dashboard');
    if (openDashboardBtn) {
      openDashboardBtn.addEventListener('click', () => {
        // ✅ FIX: Redirect to resume-upload section instead of match-scorecard
        let dashboardUrl = `${websiteUrl}/dashboard?section=resume-upload`;
        if (jdId) {
          dashboardUrl += `&jdId=${encodeURIComponent(jdId)}`;
        }
        if (criteriaId) {
          dashboardUrl += `&criteriaId=${encodeURIComponent(criteriaId)}`;
        }
        console.log('Opening dashboard with URL:', dashboardUrl);
        window.open(dashboardUrl, '_blank');
      });
    }

    originalModal.querySelector('.provaluate-cancel-btn').addEventListener('click', () => this.closeModal());
  }

  closeModal() {
    const modal = document.querySelector('#provaluate-modal');
    if (modal) {
      // ✅ ADD: Reset modal open flag
      this._isModalOpen = false;
      
      // ✅ FIX: If assessment is in progress, allow closing but keep processing in background
      if (this._isAssessing) {
        console.log('Modal closed during assessment - processing will continue in background');
        this._modalClosedDuringProcessing = true;
        this.showNotification('Assessment is running in background. You will be notified when complete.', 'info');
      }
      modal.remove();
    }
  }

  showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `provaluate-notification provaluate-notification-${type}`;
    notification.textContent = message;
    document.body.appendChild(notification);

    setTimeout(() => {
      notification.style.opacity = '0';
      setTimeout(() => notification.remove(), 300);
    }, 4000);
  }

  // ✅ NEW: Show completion notification with floating button when modal was closed
  showAssessmentCompleteNotification(result, totalResumes, jdId, criteriaId) {
    // Remove any existing completion button
    const existingBtn = document.querySelector('#provaluate-completion-btn');
    if (existingBtn) {
      existingBtn.remove();
    }

    // ✅ ADD: Show notification that analysis is complete
    this.showNotification(
      `✅ Analysis complete! ${totalResumes} resume(s) processed. Login to your ProValuate dashboard to view results.`,
      'success'
    );

    // Show floating "View Results" button with favicon image
    const floatingBtn = document.createElement('button');
    floatingBtn.id = 'provaluate-completion-btn';
    floatingBtn.className = 'provaluate-floating-btn';
    
    // ✅ FIX: Use favicon.png as the button image - transparent background, slightly larger size
    const faviconUrl = chrome.runtime.getURL('favicon.png');
    floatingBtn.innerHTML = `<img src="${faviconUrl}" alt="View Assessment Results" style="width: 48px; height: 48px; display: block;" />`;
    floatingBtn.title = 'View Assessment Results';
    floatingBtn.style.background = 'transparent';
    floatingBtn.style.border = 'none';
    floatingBtn.style.zIndex = '99999'; // Ensure it's above everything
    floatingBtn.style.padding = '0';
    floatingBtn.style.borderRadius = '0';
    floatingBtn.style.width = '48px';
    floatingBtn.style.height = '48px';
    floatingBtn.style.minWidth = '48px';
    floatingBtn.style.minHeight = '48px';
    floatingBtn.style.boxShadow = 'none';
    // Override hover state to keep transparent
    floatingBtn.addEventListener('mouseenter', () => {
      floatingBtn.style.background = 'transparent';
      floatingBtn.style.transform = 'scale(1.1)'; // Slight zoom on hover
    });
    floatingBtn.addEventListener('mouseleave', () => {
      floatingBtn.style.background = 'transparent';
      floatingBtn.style.transform = 'scale(1)';
    });
    
    floatingBtn.addEventListener('click', () => {
      const websiteUrl = this.getWebsiteUrl();
      // ✅ FIX: Redirect to resume-upload section instead of match-scorecard
      let dashboardUrl = `${websiteUrl}/dashboard?section=resume-upload`;
      if (jdId) {
        dashboardUrl += `&jdId=${encodeURIComponent(jdId)}`;
      }
      if (criteriaId) {
        dashboardUrl += `&criteriaId=${encodeURIComponent(criteriaId)}`;
      }
      console.log('Opening dashboard with URL:', dashboardUrl);
      window.open(dashboardUrl, '_blank');
      floatingBtn.remove(); // Remove button after clicking
    });

    document.body.appendChild(floatingBtn);

    // Auto-remove button after 60 seconds (optional - user can still click before then)
    setTimeout(() => {
      if (floatingBtn.parentNode) {
        floatingBtn.style.transition = 'opacity 0.3s ease';
        floatingBtn.style.opacity = '0';
        setTimeout(() => {
          if (floatingBtn.parentNode) {
            floatingBtn.remove();
          }
        }, 300);
      }
    }, 60000);
  }
}

// Initialize on load
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    new ProValuateEmailPlugin();
  });
} else {
  new ProValuateEmailPlugin();
}

