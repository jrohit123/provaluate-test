// Popup script for ProValuate settings

const DEFAULT_API_BASE = 'https://flask-6421997997235322.kloudbeansite.com';

const decodeValue = (value) => {
  if (value == null) return value;
  try {
    return decodeURIComponent(value);
  } catch (error) {
    return value;
  }
};

document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('settings-form');
  const statusDiv = document.getElementById('status');
  const apiBaseInput = document.getElementById('api-base');
  const companyInput = document.getElementById('company-id');
  const userInput = document.getElementById('user-id');
  let isLoading = false;
  let saveTimeout = null;
  let lastSaved = {
    apiBase: '',
    companyId: '',
    userId: '',
  };

  const loadSettings = () => {
    isLoading = true;
    chrome.storage.sync.get(['apiBase', 'companyId', 'userId'], (result) => {
      const current = {
        apiBase: decodeValue(result.apiBase) || DEFAULT_API_BASE,
        companyId: decodeValue(result.companyId) || '',
        userId: decodeValue(result.userId) || '',
      };

      apiBaseInput.value = current.apiBase;
      companyInput.value = current.companyId;
      userInput.value = current.userId;
      lastSaved = current;
      isLoading = false;
    });
  };

  const valuesChanged = (next) => {
    return next.apiBase !== lastSaved.apiBase ||
      next.companyId !== lastSaved.companyId ||
      next.userId !== lastSaved.userId;
  };

  const persistSettings = (options = { auto: false }) => {
    if (isLoading) return;

    const current = {
      apiBase: apiBaseInput.value.trim() || DEFAULT_API_BASE,
      companyId: companyInput.value.trim(),
      userId: userInput.value.trim(),
    };

    if (!current.apiBase || !current.companyId) {
      if (!options.auto) {
        showStatus('Please fill in all required fields', 'error');
      }
      return;
    }

    if (!valuesChanged(current)) {
      return;
    }

    chrome.storage.sync.set({
      apiBase: current.apiBase,
      companyId: current.companyId,
      userId: current.userId,
    }, () => {
      lastSaved = current;
      if (options.auto) {
        showStatus('Settings saved automatically', 'success');
      } else {
        showStatus('Settings saved successfully!', 'success');
      }

      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0]) {
          chrome.tabs.sendMessage(tabs[0].id, { action: 'reloadConfig' });
        }
      });
    });
  };

  const requestCredentialSync = () => {
    try {
      chrome.runtime.sendMessage({ action: 'syncCookies' }, () => {
        if (chrome.runtime.lastError) {
          console.warn('ProValuate popup: sync request error', chrome.runtime.lastError.message);
        }
        loadSettings();
      });
    } catch (error) {
      console.warn('ProValuate popup: unable to request sync', error);
      loadSettings();
    }
  };

  requestCredentialSync();

  const scheduleAutoSave = () => {
    if (isLoading) return;
    if (saveTimeout) clearTimeout(saveTimeout);
    saveTimeout = setTimeout(() => persistSettings({ auto: true }), 500);
  };

  [apiBaseInput, companyInput, userInput].forEach((input) => {
    input.addEventListener('input', scheduleAutoSave);
    input.addEventListener('blur', () => persistSettings({ auto: true }));
  });

  // Handle form submission
  form.addEventListener('submit', (e) => {
    e.preventDefault();

    persistSettings({ auto: false });
  });
  
  function showStatus(message, type) {
    statusDiv.textContent = message;
    statusDiv.className = `status ${type}`;
    
    setTimeout(() => {
      statusDiv.className = 'status';
    }, 3000);
  }
});

