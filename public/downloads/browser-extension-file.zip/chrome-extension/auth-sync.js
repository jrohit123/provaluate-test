(function () {
  const STORAGE_KEYS = {
    apiBase: 'provaluate_api_base',
    companyId: 'provaluate_company_id',
    userId: 'provaluate_user_id',
    websiteUrl: 'provaluate_website_url',
  };

  let lastSnapshot = null;

  function log(...args) {
    try {
      console.log('ProValuate auth-sync:', ...args);
    } catch (error) {
      /* ignore logging errors */
    }
  }

  log('content script loaded');

  function decodeValue(value) {
    if (value == null) return value;
    try {
      return decodeURIComponent(value);
    } catch (error) {
      return value;
    }
  }

  function readCredentialSnapshot() {
    try {
      const snapshot = {
        apiBase: decodeValue(localStorage.getItem(STORAGE_KEYS.apiBase) || ''),
        companyId: decodeValue(localStorage.getItem(STORAGE_KEYS.companyId) || ''),
        userId: decodeValue(localStorage.getItem(STORAGE_KEYS.userId) || ''),
        websiteUrl: decodeValue(localStorage.getItem(STORAGE_KEYS.websiteUrl) || window.location.origin),
      };
      return snapshot;
    } catch (error) {
      log('unable to read localStorage', error);
      return null;
    }
  }

  function snapshotsEqual(a, b) {
    if (!a || !b) return false;
    return a.apiBase === b.apiBase &&
      a.companyId === b.companyId &&
      a.userId === b.userId &&
      a.websiteUrl === b.websiteUrl;
  }

  function syncWithBackground(snapshot) {
    if (!snapshot) return;
    const payload = {
      apiBase: snapshot.apiBase || undefined,
      companyId: snapshot.companyId || undefined,
      userId: snapshot.userId || undefined,
      websiteUrl: snapshot.websiteUrl || undefined,
    };

    if (chrome?.storage?.sync?.set) {
      const storageData = {};
      Object.entries(payload).forEach(([key, value]) => {
        if (value !== undefined && value !== null && value !== '') {
          storageData[key] = value;
        }
      });

      if (Object.keys(storageData).length > 0) {
        chrome.storage.sync.set(storageData, () => {
          if (chrome.runtime?.lastError) {
            log('storage.set error', chrome.runtime.lastError.message);
          } else {
            log('credentials stored to chrome.storage', storageData);
          }
        });
      }
    }

    if (!chrome || !chrome.runtime || !chrome.runtime.sendMessage) {
      log('chrome.runtime not available for messaging, stored locally instead');
      return;
    }

    log('syncing credentials to background', payload);
    chrome.runtime.sendMessage({
      action: 'saveConfig',
      ...payload,
    }, (response) => {
      if (chrome.runtime.lastError) {
        log('saveConfig error', chrome.runtime.lastError.message);
        return;
      }
      if (response && response.success) {
        log('background confirmed credential sync');
      } else {
        log('saveConfig response unexpected', response);
      }
    });
  }

  function checkAndSync() {
    const snapshot = readCredentialSnapshot();
    if (!snapshot) return;

    if (!lastSnapshot || !snapshotsEqual(snapshot, lastSnapshot)) {
      log('detected credential change', snapshot);
      lastSnapshot = snapshot;
      syncWithBackground(snapshot);
    }
  }

  // Initial sync on load
  checkAndSync();

  // Observe localStorage changes triggered in other tabs/windows
  window.addEventListener('storage', (event) => {
    if (!event || !event.key) return;
    if (Object.values(STORAGE_KEYS).includes(event.key)) {
      setTimeout(checkAndSync, 50);
    }
  });

  // Periodic sync as fallback
  setInterval(checkAndSync, 2000);
})();
