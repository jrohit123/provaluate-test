// ProValuate Background Service Worker
// Handles API key storage, cookie syncing, and cross-tab communication

// Get the website URL from environment or use default
const DEFAULT_WEBSITE_URL = 'https://devprovaluate.aitamate.com';
const DEFAULT_API_BASE = 'https://devprovaluate_py.aitamate.com';

const decodeValue = (value) => {
  if (value == null) return value;
  try {
    return decodeURIComponent(value);
  } catch (error) {
    return value;
  }
};

const getWebsiteUrl = () => {
  // Try to get from storage, fallback to default development URL
  return new Promise((resolve) => {
    chrome.storage.sync.get(['websiteUrl'], (result) => {
      resolve(decodeValue(result.websiteUrl) || DEFAULT_WEBSITE_URL);
    });
  });
};

const getApiBaseUrl = () => {
  return new Promise((resolve) => {
    chrome.storage.sync.get(['apiBase'], (result) => {
      resolve(decodeValue(result.apiBase) || DEFAULT_API_BASE);
    });
  });
};

/**
 * Read cookies from the website domain and sync to chrome.storage.sync
 */
const COOKIE_NAMES = new Set([
  'provaluate_user_id',
  'provaluate_company_id',
  'provaluate_api_base',
  'provaluate_website_url'
]);

const LOCAL_STORAGE_KEY_MAP = {
  apiBase: 'provaluate_api_base',
  companyId: 'provaluate_company_id',
  userId: 'provaluate_user_id',
  websiteUrl: 'provaluate_website_url'
};

const getCookiesAsync = (filter) => {
  return new Promise((resolve, reject) => {
    chrome.cookies.getAll(filter, (cookies) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      resolve(cookies || []);
    });
  });
};

async function syncCookiesToStorage({ trigger } = {}) {
  try {
    const websiteUrl = await getWebsiteUrl();
    console.log('🔄 ProValuate: Starting cookie sync from:', websiteUrl, trigger ? `(trigger: ${trigger})` : '');

    const storeFromCookies = async (cookies) => {
      if (!cookies || cookies.length === 0) {
        return false;
      }

      const relevant = cookies.filter((cookie) => COOKIE_NAMES.has(cookie.name));
      if (relevant.length === 0) {
        return false;
      }

      await processCookies(relevant);
      return true;
    };

    // Method 1: precise URL lookup
    try {
      const cookies = await getCookiesAsync({ url: websiteUrl });
      if (await storeFromCookies(cookies)) {
        console.log('✅ Cookie sync succeeded via direct URL lookup');
        return true;
      }
    } catch (lookupError) {
      console.warn('⚠️ Method 1 failed:', lookupError.message);
    }

    // Method 2: global search
    try {
      const allCookies = await getCookiesAsync({});
      console.log('🔍 Method 2: Checking all cookies, found:', allCookies.length);
      const matched = allCookies.filter((c) => {
        const isRelevant = COOKIE_NAMES.has(c.name);
        if (isRelevant) {
          console.log('🍪 Found relevant cookie:', c.name, 'domain:', c.domain, 'value:', c.value);
        }
        return isRelevant;
      });

      if (await storeFromCookies(matched)) {
        console.log('✅ Cookie sync succeeded via global lookup');
        return true;
      }
    } catch (globalError) {
      console.warn('⚠️ Method 2 failed:', globalError.message);
    }

    console.warn('⚠️ No relevant cookies found; attempting localStorage fallback');

    if (await trySyncFromLocalStorageViaScripting()) {
      console.log('✅ Synced credentials via localStorage fallback');
      return true;
    }

    console.warn('⚠️ LocalStorage fallback failed; attempting backend fetch');
    return await tryFetchFromBackend();
  } catch (error) {
    console.error('❌ Error syncing cookies:', error);

    if (await trySyncFromLocalStorageViaScripting()) {
      console.log('✅ Synced credentials via localStorage fallback after error');
      return true;
    }

    return await tryFetchFromBackend();
  }
}

async function trySyncFromLocalStorageViaScripting() {
  if (!chrome?.scripting?.executeScript || !chrome?.tabs?.query) {
    return false;
  }

  const urlPatterns = [
    'https://devprovaluate.aitamate.com/*',
    'http://devprovaluate.aitamate.com/*',
    'https://*.aitamate.com/*',
    'http://*.aitamate.com/*'
  ];

  let tabs = [];
  try {
    tabs = await chrome.tabs.query({ url: urlPatterns });
  } catch (error) {
    console.warn('⚠️ Unable to query tabs for localStorage fallback:', error);
    return false;
  }

  for (const tab of tabs) {
    try {
      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
          try {
            return {
              apiBase: localStorage.getItem('provaluate_api_base') || '',
              companyId: localStorage.getItem('provaluate_company_id') || '',
              userId: localStorage.getItem('provaluate_user_id') || '',
              websiteUrl: localStorage.getItem('provaluate_website_url') || ''
            };
          } catch (error) {
            return null;
          }
        }
      });

      if (!Array.isArray(results) || !results.length) {
        continue;
      }

      const [result] = results;
      const snapshot = result?.result;
      if (!snapshot) {
        continue;
      }

      const cookiePayload = Object.entries(LOCAL_STORAGE_KEY_MAP)
        .map(([key, storageKey]) => {
          const value = decodeValue(snapshot[key]);
          if (!value) return null;
          return { name: storageKey, value };
        })
        .filter(Boolean);

      if (cookiePayload.length === 0) {
        continue;
      }

      await processCookies(cookiePayload);
      return true;
    } catch (error) {
      console.warn('⚠️ Failed to read localStorage from tab', tab.id, error);
    }
  }

  return false;
}

/**
 * Fallback: Try to fetch credentials from backend API
 */
async function tryFetchFromBackend() {
  console.log('🔄 Trying to fetch credentials from backend API...');
  const apiBase = await getApiBaseUrl();
  const cleanedBase = decodeValue(apiBase || DEFAULT_API_BASE).replace(/\/$/, '');

  const candidates = (() => {
    const urls = new Set();
    if (cleanedBase) {
      urls.add(cleanedBase);
      if (cleanedBase.startsWith('https://')) {
        urls.add(`http://${cleanedBase.slice(8)}`);
      } else if (cleanedBase.startsWith('http://')) {
        urls.add(`https://${cleanedBase.slice(7)}`);
      }
    }
    return Array.from(urls);
  })();

  for (const base of candidates) {
    const apiUrl = `${base}/api/get-user-credentials`;
    console.log('🌐 Attempting backend credential fetch from', apiUrl);

    try {
      const response = await fetch(apiUrl, {
        method: 'GET',
        credentials: 'include'
      });

      if (!response.ok) {
        console.warn('⚠️ Backend API request failed:', response.status, apiUrl);
        continue;
      }

      const data = await response.json();
      const userId = decodeValue(data.user_id);
      const companyId = decodeValue(data.company_id);
      if (data.status === 'success' && userId && companyId) {
        console.log('✅ Fetched credentials from backend API');
        await processCookies([
          { name: 'provaluate_user_id', value: userId },
          { name: 'provaluate_company_id', value: companyId },
          { name: 'provaluate_api_base', value: base }
        ]);
        return true;
      }

      console.warn('⚠️ Backend API returned invalid data structure', data);
    } catch (error) {
      console.error('❌ Backend API fetch error for', apiUrl, error);
    }
  }
}

/**
 * Process cookies and update chrome.storage.sync
 */
async function processCookies(cookies) {
  let userId = null;
  let companyId = null;
  let apiBase = null;
  let websiteUrl = null;

  // Extract user_id and company_id from cookies
  cookies.forEach(cookie => {
    const decodedValue = decodeValue(cookie.value);
    if (cookie.name === 'provaluate_user_id') {
      userId = decodedValue;
    } else if (cookie.name === 'provaluate_company_id') {
      companyId = decodedValue;
    } else if (cookie.name === 'provaluate_api_base') {
      apiBase = decodedValue;
    } else if (cookie.name === 'provaluate_website_url') {
      websiteUrl = decodedValue;
    }
  });

  // Get existing storage to preserve apiBase
  return new Promise((resolve) => {
    chrome.storage.sync.get(['apiBase', 'websiteUrl', 'userId', 'companyId'], (result) => {
      const storageData = {};

      storageData.apiBase = decodeValue(apiBase || result.apiBase || DEFAULT_API_BASE);
      storageData.websiteUrl = decodeValue(websiteUrl || result.websiteUrl || DEFAULT_WEBSITE_URL);

      if (userId) {
        storageData.userId = userId;
        console.log('✅ Synced userId from cookie:', userId);
      } else if (result.userId) {
        storageData.userId = decodeValue(result.userId);
      } else {
        storageData.userId = null;
        console.warn('⚠️ No userId cookie found');
      }

      if (companyId) {
        storageData.companyId = companyId;
        console.log('✅ Synced companyId from cookie:', companyId);
      } else if (result.companyId) {
        storageData.companyId = decodeValue(result.companyId);
      } else {
        storageData.companyId = null;
        console.warn('⚠️ No companyId cookie found');
      }

      chrome.storage.sync.set(storageData, () => {
        console.log('✅ Stored credentials from cookie sync');
        resolve(true);
      });
    });
  });
}

// Initial sync on install
chrome.runtime.onInstalled.addListener(() => {
  console.log('ProValuate extension installed');
  
  // Set default API base and website URL (credentials will come from cookies)
  chrome.storage.sync.set({
    apiBase: DEFAULT_API_BASE,
    websiteUrl: DEFAULT_WEBSITE_URL
  }, () => {
    // Sync cookies after setting defaults
    syncCookiesToStorage({ trigger: 'startup' });
  });
});

// Sync cookies periodically (every 5 minutes)
setInterval(() => {
  syncCookiesToStorage();
}, 5 * 60 * 1000);

// Sync cookies when extension starts
syncCookiesToStorage({ trigger: 'startup' });

// Function to check if user has logged out and clear credentials
async function clearCredentialsOnLogout() {
  try {
    const websiteUrl = await getWebsiteUrl();
    const cookies = await getCookiesAsync({ url: websiteUrl });
    const relevant = cookies.filter((cookie) => COOKIE_NAMES.has(cookie.name));
    
    // Check localStorage as fallback
    const hasLocalStorage = await trySyncFromLocalStorageViaScripting();
    
    // If no relevant cookies found and no localStorage, user has logged out
    if (relevant.length === 0 && !hasLocalStorage) {
      console.log('🔓 User logged out - clearing extension credentials');
      chrome.storage.sync.set({
        userId: null,
        companyId: null
      }, () => {
        console.log('✅ Extension credentials cleared');
      });
      return true;
    }
    return false;
  } catch (error) {
    console.error('Error checking logout status:', error);
    return false;
  }
}

chrome.cookies.onChanged.addListener((changeInfo) => {
  if (!changeInfo || !changeInfo.cookie) return;
  const { cookie } = changeInfo;
  if (!COOKIE_NAMES.has(cookie.name)) return;
  
  // Check if cookie was removed (logout)
  if (changeInfo.removed) {
    console.log('🔓 Cookie removed:', cookie.name, '- checking for logout');
    clearCredentialsOnLogout();
  } else {
  console.log('🔔 Cookie change detected for', cookie.name, '- resyncing credentials');
  syncCookiesToStorage({ trigger: 'cookieChanged' });
  }
});

// Periodically check for logout (every 30 seconds)
setInterval(() => {
  clearCredentialsOnLogout();
}, 30000);

// Listen for messages from content script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getConfig') {
    chrome.storage.sync.get(['apiBase', 'companyId', 'userId'], (result) => {
      sendResponse({
        apiBase: decodeValue(result.apiBase),
        companyId: decodeValue(result.companyId),
        userId: decodeValue(result.userId)
      });
    });
    return true; // Will respond asynchronously
  }
  
  if (request.action === 'saveConfig') {
    chrome.storage.sync.get(['apiBase', 'companyId', 'userId', 'websiteUrl'], (existing) => {
      const storageData = {
        apiBase: decodeValue(request.apiBase || existing.apiBase || DEFAULT_API_BASE),
        companyId: decodeValue(request.companyId || existing.companyId || null),
        userId: decodeValue(request.userId || existing.userId || null),
        websiteUrl: decodeValue(request.websiteUrl || existing.websiteUrl || DEFAULT_WEBSITE_URL)
      };

      chrome.storage.sync.set(storageData, () => {
        console.log('💾 Saved credentials via saveConfig', storageData);
        sendResponse({ success: true });
      });
    });
    return true;
  }

  if (request.action === 'syncCookies') {
    // Manual sync trigger from content script or popup
    syncCookiesToStorage({ trigger: 'manual' })
      .then((success) => {
        sendResponse({ success });
      })
      .catch((error) => {
        console.error('❌ Manual sync failed:', error);
        sendResponse({ success: false, error: error?.message || 'Sync failed' });
      });
    return true;
  }

  if (request.action === 'downloadFile') {
    // Note: Due to browser security, we can't directly download and return files
    // The content script should handle file fetching directly
    // This is a placeholder for future enhancement
    sendResponse({ success: false, message: 'Direct download not supported' });
    return false;
  }
});
