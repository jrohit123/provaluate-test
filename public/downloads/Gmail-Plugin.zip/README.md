# ProValuate Chrome Extension - Complete Setup Guide

## Overview

The ProValuate Chrome Extension integrates directly with Gmail to enable recruiters to evaluate resumes against job descriptions without leaving their email interface. The extension automatically detects resume attachments, allows selection of job descriptions and evaluation criteria, and processes resumes in batches with real-time progress tracking.

## Features

1. **Automatic Resume Detection**: Detects PDF, DOC, DOCX, and TXT resume attachments in Gmail
2. **JD & Criteria Selection**: Dropdown menus to select from existing job descriptions and evaluation criteria
3. **Batch Processing**: Uploads and analyzes multiple resumes simultaneously
4. **Progress Tracking**: Real-time progress bar showing resume count during analysis
5. **Completion Notification**: "Done" message with summary after assessment completion
6. **Dashboard Integration**: Direct link to ProValuate dashboard to view detailed reports

## File Structure

```
ProValuate-Extension/
├── manifest.json          # Extension manifest (permissions, content scripts)
├── background.js          # Service worker (storage, cookies)
├── content.js             # Main content script (Gmail)
├── popup.html             # Settings popup UI
├── popup.js               # Settings popup logic
├── styles.css             # All extension styles
└── README.md              # This file
```

## Installation Steps

### 1. Prepare the Extension Files

1. Create a folder named `ProValuate-Extension` in your project root
2. Copy all the provided files into this folder:
   - `manifest.json`
   - `background.js`
   - `content.js`
   - `popup.html`
   - `popup.js`
   - `styles.css`

### 2. Load Extension in Chrome

1. Open Chrome and navigate to `chrome://extensions/`
2. Enable **Developer mode** (toggle in top-right corner)
3. Click **Load unpacked**
4. Select the `ProValuate-Extension` folder
5. The extension should now appear in your extensions list

### 3. Configure Extension Settings

1. Click the ProValuate extension icon in Chrome toolbar
2. Enter the following settings:
   - **API Base URL**: Your backend API URL (e.g., `https://flask-6421998707235322.kloudbeansite.com`)
   - **Company ID**: Your company ID (required - get this from your ProValuate dashboard)
   - **User ID**: Your user ID (optional - for tracking purposes)
3. Click **Save Settings**

### 4. Verify Backend API Endpoints

Ensure your Python backend (`app.py`) has the following endpoints available:

- `GET /api/job_descriptions?company_id={company_id}` - Returns list of job descriptions
- `GET /api/criteria?company_id={company_id}` - Returns list of evaluation criteria
- `POST /cv/upload` - Uploads resume files (FormData with file, jd_id, criteria_id, user_id, company_id)
- `POST /cv/analyze_resumes` - Analyzes resumes (JSON with jd_id, criteria_id, resume_urls, company_id)

## Usage Workflow

### Step 1: Open Email with Resume Attachments

1. Open Gmail in Chrome
2. Open an email that contains resume attachments (PDF, DOC, DOCX, or TXT files)
3. The extension will automatically detect resume attachments

### Step 2: Initiate Assessment

**Option A: Use Floating Button**
- Look for the floating "📊 ProValuate" button in the bottom-right corner of the page
- Click it to open the assessment modal

**Option B: Use Attachment Button**
- Look for "📊 Evaluate with ProValuate" buttons next to detected resume attachments
- Click any of these buttons to open the assessment modal

### Step 3: Select Job Description and Criteria

1. In the modal, select a **Job Description** from the dropdown (required)
2. Optionally select **Evaluation Criteria** from the dropdown
3. Review the list of detected resumes (count shown in header)
4. Click **Assess Resumes** button

### Step 4: Monitor Progress

1. The modal will show a loading state with:
   - Spinner animation
   - Progress text: "Uploading resume X of Y..."
   - Progress bar showing completion percentage
   - Resume count: "X / Y resumes"

### Step 5: View Completion

1. After all resumes are processed, you'll see:
   - Success checkmark icon
   - "Assessment Complete!" message
   - Total resume count
   - Success/failure statistics
   - Note about viewing detailed reports in dashboard
2. Click **Open Dashboard** to view detailed analysis results
3. Click **Close** to dismiss the modal

## API Integration Details

### Job Descriptions Endpoint

**Request:**
```
GET /api/job_descriptions?company_id={company_id}
```

**Response:**
```json
{
  "status": "success",
  "data": [
    {
      "jd_id": "uuid",
      "title": "Software Engineer",
      "jd_file": "https://...",
      "created_at": "2024-01-01T00:00:00"
    }
  ]
}
```

### Criteria Endpoint

**Request:**
```
GET /api/criteria?company_id={company_id}
```

**Response:**
```json
{
  "status": "success",
  "data": [
    {
      "criteria_id": "uuid",
      "criteria_name": "Technical Skills",
      "grid": [...],
      "created_at": "2024-01-01T00:00:00"
    }
  ]
}
```

### Resume Upload Endpoint

**Request:**
```
POST /cv/upload
Content-Type: multipart/form-data

FormData:
- file: File object
- jd_id: string
- criteria_id: string (optional)
- user_id: string
- company_id: string
- candidate_name: string
```

**Response:**
```json
{
  "status": "success",
  "file_url": "https://supabase-storage-url/resume.pdf",
  "resume_id": "uuid",
  "candidate_name": "John Doe"
}
```

### Analyze Resumes Endpoint

**Request:**
```
POST /cv/analyze_resumes
Content-Type: application/json

{
  "jd_id": "uuid",
  "criteria_id": "uuid" (optional),
  "resume_urls": ["https://...", "https://..."],
  "company_id": "uuid"
}
```

**Response:**
```json
{
  "status": "success",
  "message": "Successfully analyzed X resumes",
  "jd_id": "uuid",
  "successful_analyses": 5,
  "failed_analyses": 0,
  "results": [...],
  "failed_resumes": []
}
```

## Troubleshooting

### Extension Not Detecting Resumes

1. **Refresh the email page** - The extension scans for attachments on page load
2. **Check file format** - Only PDF, DOC, DOCX, and TXT files are detected
3. **Check file name** - Files with "resume", "cv", or "curriculum" in the name are prioritized
4. **Open Developer Console** (F12) and check for errors

### API Connection Issues

1. **Verify API Base URL** - Check settings popup to ensure correct URL
2. **Check CORS settings** - Ensure your backend allows requests from `chrome-extension://` origin
3. **Verify Company ID** - Ensure you've entered the correct company ID
4. **Check Network tab** - Open DevTools → Network to see API requests/responses

### File Upload Failures

1. **Check file size** - Large files may timeout
2. **Verify backend storage** - Ensure Supabase storage is configured correctly
3. **Check browser console** - Look for CORS or network errors

### Progress Not Updating

- The progress bar is estimated based on time intervals
- Actual progress depends on backend processing speed
- Check backend logs for actual processing status

### Provider DOM notes

- **Gmail**: Thread container `div[role="main"]`, message elements `[data-message-id]` / `[data-legacy-message-id]`, attachment links with `attid=`, `mail-attachment`, or "Preview attachment" text.

## Backend Requirements

### CORS Configuration

Add the following to your Flask app (`app.py`) to allow extension requests:

```python
from flask_cors import CORS

# Allow requests from Chrome extension
CORS(app, origins=[
    "chrome-extension://*",
    "http://localhost:*",
    "https://*.provaluate.com"
])
```

### Environment Variables

Ensure your backend has access to:
- `SUPABASE_URL` - Your Supabase project URL
- `SUPABASE_KEY` - Your Supabase API key

### Database Tables

The extension requires these Supabase tables:
- `job_descriptions` - Stores job descriptions
- `criteria` - Stores evaluation criteria grids
- `resumes` - Stores uploaded resume metadata
- `resume_analysis` - Stores analysis results
- `resume_scores` - Stores scoring results

## Security Considerations

1. **API Keys**: Never hardcode API keys in the extension
2. **Company ID Validation**: Backend should validate company_id on all requests
3. **File Size Limits**: Implement file size limits on upload endpoint
4. **Rate Limiting**: Backend should implement rate limiting for batch operations

## Development Notes

### Testing Locally

1. Start your Python backend: `python app.py` (or your startup command)
2. Ensure backend is running on the port specified in extension settings
3. Load extension in Chrome
4. Open Gmail and test with sample emails

### Debugging

1. **Content Script**: Open DevTools on Gmail page → Console tab
2. **Background Script**: Go to `chrome://extensions/` → Click "service worker" link
3. **Popup**: Right-click extension icon → Inspect popup

### Updating Extension

1. Make changes to extension files
2. Go to `chrome://extensions/`
3. Click refresh icon on ProValuate extension
4. Reload Gmail page

## Future Enhancements

1. **WebSocket Support**: Real-time progress updates via WebSocket
2. **Background Processing**: Process resumes in background without keeping tab open
3. **Email Integration**: Auto-reply to candidates with evaluation summary
4. **Bulk Email Processing**: Process resumes from multiple emails at once
5. **Offline Support**: Queue assessments when offline, sync when online

## Support

For issues or questions:
1. Check browser console for errors
2. Verify backend API endpoints are accessible
3. Ensure all required settings are configured
4. Review backend logs for processing errors

## Version History

- **v1.0.0** (Current)
  - Initial release
  - Gmail support
  - Batch resume processing
  - Progress tracking
  - Dashboard integration
  - Gmail-only; host_permissions for mail.google.com

