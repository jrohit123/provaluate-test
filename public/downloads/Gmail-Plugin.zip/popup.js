// Popup script for ProValuate – credentials are synced from the website (no UI to edit).

document.addEventListener('DOMContentLoaded', () => {
  // Trigger cookie sync so storage stays up to date when user opens the popup
  try {
    chrome.runtime.sendMessage({ action: 'syncCookies' }, () => {
      if (chrome.runtime.lastError) {
        console.warn('ProValuate popup: sync request error', chrome.runtime.lastError.message);
      }
    });
  } catch (error) {
    console.warn('ProValuate popup: unable to request sync', error);
  }
});
